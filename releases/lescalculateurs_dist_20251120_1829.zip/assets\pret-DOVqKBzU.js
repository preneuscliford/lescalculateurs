import{f as t}from"./main-C11GuAlR.js";import{C as M}from"./CalculatorFrame-CeXK84kH.js";import"./autoExportInit-DC5gTcqy.js";import"./chunk-jspdf-BCzl2gSH.js";const F={title:"Simulateur de prêt immobilier 2025",description:"Simulation complète : capacité d'emprunt, mensualités, assurance, frais de dossier.",fields:[{id:"prix_bien",label:"Prix du bien immobilier *",type:"number",required:!0,placeholder:"300000",min:1e4,step:1e3,suffix:"€"},{id:"apport_personnel",label:"Apport personnel *",type:"number",required:!0,placeholder:"50000",min:0,step:1e3,suffix:"€"},{id:"duree",label:"Durée du prêt *",type:"select",required:!0,options:[{value:"10",label:"10 ans"},{value:"15",label:"15 ans"},{value:"20",label:"20 ans"},{value:"25",label:"25 ans"},{value:"30",label:"30 ans"}]},{id:"taux_nominal",label:"Taux d'intérêt nominal *",type:"number",required:!0,placeholder:"4.0",min:.1,max:10,step:.1,suffix:"%"},{id:"type_pret",label:"Type de prêt",type:"select",options:[{value:"classique",label:"Prêt classique"},{value:"ptz",label:"Prêt à Taux Zéro (PTZ)"},{value:"pel",label:"Prêt Épargne Logement (PEL)"},{value:"action_logement",label:"Prêt Action Logement"}]},{id:"revenus_emprunteur1",label:"Revenus mensuels nets emprunteur 1 *",type:"number",required:!0,placeholder:"3500",min:1e3,step:100,suffix:"€"},{id:"revenus_emprunteur2",label:"Revenus mensuels nets emprunteur 2 (optionnel)",type:"number",placeholder:"0",min:0,step:100,suffix:"€"},{id:"charges_mensuelles",label:"Charges mensuelles existantes (optionnel)",type:"number",placeholder:"0",min:0,step:50,suffix:"€"},{id:"age_emprunteur",label:"Âge de l'emprunteur principal (optionnel)",type:"number",placeholder:"35",min:18,max:75},{id:"statut_professionnel",label:"Statut professionnel",type:"select",options:[{value:"cdi",label:"CDI"},{value:"cdd",label:"CDD"},{value:"freelance",label:"Indépendant/Freelance"},{value:"fonctionnaire",label:"Fonctionnaire"},{value:"retraite",label:"Retraité"}]},{id:"assurance_taux",label:"Taux d'assurance emprunteur",type:"number",placeholder:"0.36",min:.1,max:2,step:.01,suffix:"%"},{id:"frais_dossier",label:"Frais de dossier (optionnel)",type:"number",placeholder:"0",min:0,step:100,suffix:"€"},{id:"frais_garantie",label:"Frais de garantie (optionnel)",type:"number",placeholder:"0",min:0,step:100,suffix:"€"}],calculate:s=>{try{const e=s.prix_bien||0,a=s.apport_personnel||0,n=e-a;if(n<=0)return{success:!1,error:"L'apport ne peut pas être supérieur ou égal au prix du bien"};const c=parseInt(s.duree)||20,r=c*12,m=(s.taux_nominal||4)/100,i=m/12,o=(s.revenus_emprunteur1||0)+(s.revenus_emprunteur2||0),v=s.charges_mensuelles||0,I=o-v,g=(s.assurance_taux||.36)/100,x=s.frais_dossier||0,b=s.frais_garantie||0;let l=0;i>0?l=n*i*Math.pow(1+i,r)/(Math.pow(1+i,r)-1):l=n/r;const p=n*g/12,u=l+p,f=u*r-n,d=p*r,y=f-d,h=u/o*100,$=o*.33,_=Math.max(0,$-u),T=x+b+d,C=n+T,A=(l*r/C-1)*100;return{success:!0,data:{prixBien:e,apportPersonnel:a,montantEmprunte:n,dureeAnnees:c,tauxNominal:m*100,mensualiteCapitalInterets:l,assuranceMensuelle:p,mensualiteTotale:u,coutTotalInterets:y,coutTotalAssurance:d,coutTotalCredit:f,tauxEndettement:h,capaciteRestante:_,revenusMensuels:o,fraisDossier:x,fraisGarantie:b,taeg:A}}}catch{return{success:!1,error:"Erreur dans le calcul du prêt immobilier"}}},formatResult:s=>{const e=s.data,a=e.tauxEndettement<=33;return`
          <div class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div class="bg-blue-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800">Prix du bien</h4>
                <p class="text-xl font-bold text-blue-600">${t(e.prixBien)}</p>
                <p class="text-sm text-gray-600">Apport : ${t(e.apportPersonnel)}</p>
              </div>
              <div class="bg-green-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800">Montant emprunté</h4>
                <p class="text-xl font-bold text-green-600">${t(e.montantEmprunte)}</p>
                <p class="text-sm text-gray-600">Sur ${e.dureeAnnees} ans</p>
              </div>
              <div class="bg-purple-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800">Mensualité totale</h4>
                <p class="text-xl font-bold text-purple-600">${t(e.mensualiteTotale)}</p>
                <p class="text-sm text-gray-600">Capital + Intérêts + Assurance</p>
              </div>
            </div>

            <div class="bg-gray-50 p-4 rounded-lg">
              <h4 class="font-semibold text-gray-800 mb-3">Détail des mensualités :</h4>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                <div><span class="font-medium">Capital + Intérêts :</span> ${t(e.mensualiteCapitalInterets)}</div>
                <div><span class="font-medium">Assurance :</span> ${t(e.assuranceMensuelle)}</div>
                <div><span class="font-medium">Taux nominal :</span> ${e.tauxNominal.toFixed(2)}%</div>
                <div><span class="font-medium">TAEG (approx.) :</span> ${e.taeg.toFixed(2)}%</div>
              </div>
            </div>

            <div class="border-t pt-4">
              <h4 class="font-semibold text-gray-800 mb-3">Coûts totaux sur ${e.dureeAnnees} ans :</h4>
              <div class="space-y-2 text-sm">
                <div class="flex justify-between">
                  <span>Intérêts :</span>
                  <span class="font-medium">${t(e.coutTotalInterets)}</span>
                </div>
                <div class="flex justify-between">
                  <span>Assurance :</span>
                  <span class="font-medium">${t(e.coutTotalAssurance)}</span>
                </div>
                <div class="flex justify-between">
                  <span>Frais de dossier :</span>
                  <span class="font-medium">${t(e.fraisDossier)}</span>
                </div>
                <div class="flex justify-between">
                  <span>Frais de garantie :</span>
                  <span class="font-medium">${t(e.fraisGarantie)}</span>
                </div>
                <div class="flex justify-between border-t pt-2 font-semibold text-lg">
                  <span>Coût total du crédit :</span>
                  <span class="text-red-600">${t(e.coutTotalCredit)}</span>
                </div>
              </div>
            </div>

            <div class="${a?"bg-green-50 border-green-200":"bg-red-50 border-red-200"} border rounded-lg p-4">
              <h4 class="font-semibold ${a?"text-green-800":"text-red-800"} mb-2">
                ${a?"✅":"⚠️"} Taux d'endettement : ${e.tauxEndettement.toFixed(1)}%
              </h4>
              <p class="text-sm ${a?"text-green-700":"text-red-700"}">
                ${a?`Votre taux d'endettement est acceptable (≤ 33%). Capacité restante : ${t(e.capaciteRestante)}/mois`:"Attention : votre taux d'endettement dépasse 33%. Le prêt pourrait être refusé par la banque."}
              </p>
              <p class="text-xs mt-2 ${a?"text-green-600":"text-red-600"}">
                Revenus mensuels nets : ${t(e.revenusMensuels)} | Mensualité : ${t(e.mensualiteTotale)}
              </p>
            </div>

            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p class="text-sm text-blue-800">
                <strong>💡 Conseil :</strong> Cette simulation est indicative. Les banques étudient aussi votre profil, 
                apport, stabilité professionnelle, et peuvent proposer des conditions différentes.
              </p>
            </div>
          </div>
          `}};new M("calculator-container",F);
