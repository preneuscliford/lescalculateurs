import"./main-C11GuAlR.js";import"./autoExportInit-DC5gTcqy.js";import"./chunk-jspdf-BCzl2gSH.js";document.getElementById("plusvalue-form").addEventListener("submit",function(u){u.preventDefault();const n=parseFloat(document.getElementById("prixVente").value)||0,d=parseFloat(document.getElementById("prixAchat").value)||0,v=parseFloat(document.getElementById("fraisAchat").value)||0,x=parseFloat(document.getElementById("travaux").value)||0,b=new Date(document.getElementById("dateAchat").value),f=new Date(document.getElementById("dateVente").value),g=document.getElementById("typeBien").value;if(!n||!d||!b||!f){alert("Veuillez remplir tous les champs obligatoires");return}const t=(f-b)/(1e3*60*60*24*365.25),r=Math.floor(t);let p=d+v+x;if(t>5){const e=d*.15;e>x&&(p=d+v+e)}const l=n-p;if(l<=0){document.getElementById("results").innerHTML=`
            <div class="bg-blue-50 border-l-4 border-blue-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-blue-900 mb-4">✅ Aucun impôt à payer</h3>
              <p class="text-gray-700">Vous n'avez pas de plus-value imposable. La vente génère une moins-value de <strong>${Math.abs(l).toLocaleString("fr-FR")} €</strong>.</p>
            </div>
          `,document.getElementById("results").classList.remove("hidden");return}let o=0,i=0;t>=22?o=100:t>=6&&(o=(r-5)*6),t>=30?i=100:t>=22?i=87+(r-21)*9:t>=6&&(i=(r-5)*1.65);const c=l*(1-o/100),y=l*(1-i/100),B=.19,w=.172;let I=c*B;const h=y*w;let s=0;if(c>5e4){const e=c-5e4;e<=1e4?s=e*.02:e<=2e4?s=200+(e-1e4)*.03:e<=3e4?s=500+(e-2e4)*.04:e<=4e4?s=900+(e-3e4)*.05:s=1400+(e-4e4)*.06}const m=I+s+h,E=l-m;function a(e){return new Intl.NumberFormat("fr-FR",{style:"currency",currency:"EUR"}).format(e)}const $=`
          <div class="space-y-6">
            <div class="bg-blue-50 border-l-4 border-blue-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-blue-900 mb-4">📊 Détail du calcul</h3>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p class="text-sm text-gray-600">Durée de détention</p>
                  <p class="text-lg font-semibold text-gray-900">${r} ans ${Math.round((t-r)*12)} mois</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Prix de revient</p>
                  <p class="text-lg font-semibold text-gray-900">${a(p)}</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Plus-value brute</p>
                  <p class="text-lg font-semibold text-gray-900">${a(l)}</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Type de bien</p>
                  <p class="text-lg font-semibold text-gray-900">${g==="secondaire"?"Résidence secondaire":g==="investissement"?"Investissement locatif":"Terrain à bâtir"}</p>
                </div>
              </div>
            </div>

            <div class="bg-green-50 border-l-4 border-green-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-green-900 mb-4">💰 Abattements appliqués</h3>
              <div class="space-y-3">
                <div class="flex justify-between">
                  <span class="text-gray-600">Abattement impôt sur le revenu :</span>
                  <span class="font-semibold text-green-700">${o.toFixed(1)}%</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Abattement prélèvements sociaux :</span>
                  <span class="font-semibold text-green-700">${i.toFixed(1)}%</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Plus-value taxable (IR) :</span>
                  <span class="font-semibold">${a(c)}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Plus-value taxable (PS) :</span>
                  <span class="font-semibold">${a(y)}</span>
                </div>
              </div>
            </div>

            <div class="bg-red-50 border-l-4 border-red-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-red-900 mb-4">💸 Impôts à payer</h3>
              <div class="space-y-3">
                <div class="flex justify-between">
                  <span class="text-gray-600">Impôt sur le revenu (19%) :</span>
                  <span class="font-semibold">${a(I)}</span>
                </div>
                ${s>0?`
                <div class="flex justify-between">
                  <span class="text-gray-600">Surtaxe (plus-value &gt; 50k€) :</span>
                  <span class="font-semibold">${a(s)}</span>
                </div>
                `:""}
                <div class="flex justify-between">
                  <span class="text-gray-600">Prélèvements sociaux (17,2%) :</span>
                  <span class="font-semibold">${a(h)}</span>
                </div>
                <div class="border-t pt-2 flex justify-between text-lg">
                  <span class="font-bold text-gray-900">Total des impôts :</span>
                  <span class="font-bold text-red-700">${a(m)}</span>
                </div>
              </div>
            </div>

            <div class="bg-purple-50 border-l-4 border-purple-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-purple-900 mb-4">🎯 Résultat final</h3>
              <div class="space-y-3">
                <div class="flex justify-between text-lg">
                  <span class="font-bold text-gray-900">Plus-value nette (après impôts) :</span>
                  <span class="font-bold text-purple-700">${a(E)}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Taux d'imposition effectif :</span>
                  <span class="font-semibold">${(m/l*100).toFixed(1)}%</span>
                </div>
              </div>
            </div>

            <div class="text-sm text-gray-500 bg-gray-50 p-4 rounded">
              <p><strong>💡 Bon à savoir :</strong></p>
              <ul class="list-disc list-inside mt-2 space-y-1">
                <li>Exonération totale après 30 ans de détention</li>
                <li>La résidence principale est toujours exonérée</li>
                <li>Possibilité d'abattement forfaitaire de 15% si détention > 5 ans</li>
                <li>Ces calculs sont indicatifs, consultez un fiscaliste</li>
              </ul>
            </div>
          </div>
        `;window.plusValueData={prixVente:n,prixAchat:d,fraisAchat:v,travaux:x,dateAchat:b,dateVente:f,typeBien:g,dureeDetention:t,prixRevient:p,plusValueBrute:l,abattementIR:o,abattementPS:i,plusValueIR:c,plusValuePS:y,impotIR:I,impotPS:h,surtaxe:s,impotTotal:m,plusValueNette:E},document.getElementById("results").innerHTML=$,document.getElementById("results").classList.remove("hidden"),document.getElementById("results").scrollIntoView({behavior:"smooth"})});document.addEventListener("DOMContentLoaded",()=>{const u=new Date,n=new Date;n.setFullYear(u.getFullYear()-5),document.getElementById("dateVente").value=u.toISOString().split("T")[0],document.getElementById("dateAchat").value=n.toISOString().split("T")[0]});
