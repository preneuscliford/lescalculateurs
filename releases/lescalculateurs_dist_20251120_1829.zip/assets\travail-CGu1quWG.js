import{f as r}from"./main-C11GuAlR.js";import{C as y}from"./CalculatorFrame-CeXK84kH.js";import{b as n}from"./baremes-BY9f5jXV.js";import"./autoExportInit-DC5gTcqy.js";import"./chunk-jspdf-BCzl2gSH.js";const M={title:"Calculateur durée légale du travail",description:"Calculez vos heures supplémentaires et majorations selon le code du travail.",fields:[{id:"heures_semaine",label:"Heures travaillées par semaine",type:"number",required:!0,placeholder:"39",min:1,max:60,step:.5},{id:"salaire_horaire",label:"Salaire horaire de base (€)",type:"number",required:!0,placeholder:"15.50",min:11.65,step:.01},{id:"periode",label:"Période de calcul",type:"select",required:!0,options:[{value:"semaine",label:"Hebdomadaire"},{value:"mois",label:"Mensuel (4,33 semaines)"},{value:"annuel",label:"Annuel"}]}],calculate:t=>{try{const e=t.heures_semaine,s=t.salaire_horaire,u=t.periode,d=n.duree_travail.duree_legale_hebdomadaire,p=n.duree_travail.majorations_heures_sup.de_36_43h,m=n.duree_travail.majorations_heures_sup.au_dela_43h;let b=Math.min(e,d),l=0,o=0;if(e>d){const i=e-d;l=Math.min(i,8),o=Math.max(0,i-8)}const h=b*s,v=l*s*(1+p),f=o*s*(1+m),S=h+v+f,g=l*s*p,x=o*s*m,_=g+x;let a=1,c="par semaine";u==="mois"?(a=4.33,c="par mois"):u==="annuel"&&(a=52,c="par an");let j=0;if(u==="annuel"){const i=(l+o)*52,$=n.duree_travail.contingent_annuel_heures_sup;i>$&&(j=(i-$)*n.duree_travail.repos_compensateur.taux)}return{success:!0,data:{heuresSemaine:e,heuresNormales:b*a,heuresSup1:l*a,heuresSup2:o*a,salaireNormal:h*a,salaireSup1:v*a,salaireSup2:f*a,salaireTotal:S*a,montantMajoration1:g*a,montantMajoration2:x*a,totalMajorations:_*a,reposCompensateur:j,libellePeriode:c,salaireHoraire:s,majoration1:p,majoration2:m}}}catch{return{success:!1,error:"Erreur lors du calcul. Vérifiez vos données."}}},formatResult:t=>{const e=t.data;return`
          <div class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div class="bg-blue-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800">Heures ${e.libellePeriode}</h4>
                <p class="text-xl font-bold text-primary-600">${e.heuresSemaine}h ${e.libellePeriode==="par semaine"?"":e.libellePeriode}</p>
              </div>
              <div class="bg-green-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800">Salaire total ${e.libellePeriode}</h4>
                <p class="text-xl font-bold text-green-600">${r(e.salaireTotal)}</p>
              </div>
            </div>
            
            <div class="border-t pt-4">
              <h4 class="font-semibold text-gray-800 mb-3">Répartition des heures ${e.libellePeriode} :</h4>
              <div class="space-y-2 text-sm">
                <div class="flex justify-between">
                  <span>Heures normales (≤35h) :</span>
                  <span class="font-medium">${e.heuresNormales.toFixed(1)}h</span>
                </div>
                ${e.heuresSup1>0?`
                <div class="flex justify-between">
                  <span>Heures sup. majorées +${e.majoration1*100}% :</span>
                  <span class="font-medium">${e.heuresSup1.toFixed(1)}h</span>
                </div>
                `:""}
                ${e.heuresSup2>0?`
                <div class="flex justify-between">
                  <span>Heures sup. majorées +${e.majoration2*100}% :</span>
                  <span class="font-medium">${e.heuresSup2.toFixed(1)}h</span>
                </div>
                `:""}
              </div>
            </div>

            <div class="border-t pt-4">
              <h4 class="font-semibold text-gray-800 mb-3">Répartition du salaire ${e.libellePeriode} :</h4>
              <div class="space-y-2 text-sm">
                <div class="flex justify-between">
                  <span>Salaire de base :</span>
                  <span class="font-medium">${r(e.salaireNormal)}</span>
                </div>
                ${e.salaireSup1>0?`
                <div class="flex justify-between">
                  <span>Heures sup. +25% :</span>
                  <span class="font-medium">${r(e.salaireSup1)}</span>
                </div>
                `:""}
                ${e.salaireSup2>0?`
                <div class="flex justify-between">
                  <span>Heures sup. +50% :</span>
                  <span class="font-medium">${r(e.salaireSup2)}</span>
                </div>
                `:""}
                ${e.totalMajorations>0?`
                <div class="flex justify-between text-green-600">
                  <span>Total majorations :</span>
                  <span class="font-medium">+${r(e.totalMajorations)}</span>
                </div>
                `:""}
                <div class="border-t pt-2 flex justify-between font-bold">
                  <span>Total brut :</span>
                  <span>${r(e.salaireTotal)}</span>
                </div>
              </div>
            </div>

            ${e.reposCompensateur>0?`
            <div class="bg-orange-50 border border-orange-200 rounded-lg p-4">
              <h4 class="font-semibold text-orange-800 mb-2">Repos compensateur</h4>
              <p class="text-sm text-orange-700">
                Contingent annuel dépassé : <strong>${e.reposCompensateur.toFixed(1)} heures</strong> 
                de repos compensateur obligatoire.
              </p>
            </div>
            `:""}

            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
              <p class="text-sm text-blue-800">
                <strong>Rappel :</strong> Durée légale = 35h/semaine. Majorations : +25% (36-43h), +50% (>43h). 
                Contingent annuel : 220h. Au-delà : repos compensateur obligatoire.
              </p>
            </div>
          </div>
        `}};new y("travail-calculator",M);
