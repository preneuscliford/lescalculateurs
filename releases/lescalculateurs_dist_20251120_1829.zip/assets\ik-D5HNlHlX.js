import{f as u}from"./main-C11GuAlR.js";import{C as c}from"./CalculatorFrame-CeXK84kH.js";import{b as a}from"./baremes-BY9f5jXV.js";import"./autoExportInit-DC5gTcqy.js";import"./chunk-jspdf-BCzl2gSH.js";const d={title:"Calculateur d'indemnités kilométriques 2024",description:"Calculez vos indemnités selon le barème fiscal officiel.",fields:[{id:"type_vehicule",label:"Type de véhicule",type:"select",required:!0,options:[{value:"voiture",label:"Voiture"},{value:"deux_roues",label:"Deux-roues"}]},{id:"puissance",label:"Puissance fiscale (CV)",type:"select",required:!0,options:[{value:"3CV et moins",label:"3 CV et moins"},{value:"4CV",label:"4 CV"},{value:"5CV",label:"5 CV"},{value:"6CV",label:"6 CV"},{value:"7CV et plus",label:"7 CV et plus"}]},{id:"cylindree_moto",label:"Cylindrée (deux-roues)",type:"select",required:!1,options:[{value:"moins_50cc",label:"Moins de 50cc"},{value:"50cc_125cc",label:"50cc à 125cc"},{value:"plus_125cc",label:"Plus de 125cc"}]},{id:"kilometres",label:"Nombre de kilomètres annuels",type:"number",required:!0,placeholder:"15000",min:1,step:1}],calculate:s=>{try{const i=s.type_vehicule,e=Number(s.kilometres);if(!i)return{success:!1,error:"Veuillez sélectionner le type de véhicule."};if(!isFinite(e)||e<=0)return{success:!1,error:"Veuillez saisir un nombre de kilomètres valide."};let n=0,t=0;if(i==="voiture"){const r=s.puissance;if(!r)return{success:!1,error:"Veuillez sélectionner la puissance fiscale (CV)."};const l=a.indemnites_kilometriques.voiture[2024].find(o=>o.puissance===r);if(!l)return{success:!1,error:"Puissance non trouvée dans le barème 2024."};e<=5e3?(t=e*l.jusqu_5000,n=l.jusqu_5000):e<=2e4?(t=5e3*l.jusqu_5000+(e-5e3)*l.de_5001_20000,n=t/e):(t=5e3*l.jusqu_5000+15e3*l.de_5001_20000+(e-2e4)*l.au_dela_20000,n=t/e)}else{const r=s.cylindree_moto;if(!r)return{success:!1,error:"Veuillez sélectionner la cylindrée (deux-roues)."};const l=a.indemnites_kilometriques.deux_roues[r];if(!isFinite(l))return{success:!1,error:"Cylindrée non trouvée dans le barème."};n=l,t=e*n}return{success:!0,data:{total:t,indemniteParKm:n,kilometres:e,typeVehicule:i,puissance:s.puissance,cylindree:s.cylindree_moto}}}catch{return{success:!1,error:"Erreur lors du calcul. Vérifiez vos données."}}},formatResult:s=>{const i=s.data;return`
          <div class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div class="bg-blue-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800">Distance annuelle</h4>
                <p class="text-xl font-bold text-primary-600">${i.kilometres.toLocaleString()} km</p>
              </div>
              <div class="bg-green-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800">Indemnités totales</h4>
                <p class="text-xl font-bold text-green-600">${u(i.total)}</p>
              </div>
            </div>
            
            <div class="border-t pt-4">
              <div class="space-y-2 text-sm">
                <div class="flex justify-between">
                  <span>Type de véhicule :</span>
                  <span class="font-medium">${i.typeVehicule==="voiture"?"Voiture":"Deux-roues"}</span>
                </div>
                ${i.puissance?`
                <div class="flex justify-between">
                  <span>Puissance fiscale :</span>
                  <span class="font-medium">${i.puissance}</span>
                </div>
                `:""}
                ${i.cylindree?`
                <div class="flex justify-between">
                  <span>Cylindrée :</span>
                  <span class="font-medium">${i.cylindree.replace("_"," ")}</span>
                </div>
                `:""}
                <div class="flex justify-between">
                  <span>Indemnité moyenne par km :</span>
                  <span class="font-medium">${i.indemniteParKm.toFixed(3)} €</span>
                </div>
              </div>
            </div>

            <div class="bg-orange-50 border border-orange-200 rounded-lg p-4 mt-4">
              <p class="text-sm text-orange-800">
                <strong>⚠️ Attention :</strong> Ce calculateur utilise le barème fiscal 2024 (derniers taux officiels publiés). 
                Les barèmes 2025 ne sont pas encore disponibles - ils sont généralement publiés entre mars et avril.
              </p>
            </div>
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
              <p class="text-sm text-blue-800">
                <strong>À savoir :</strong> Ces indemnités sont déductibles fiscalement et doivent être 
                déclarées dans vos frais réels ou remboursées par votre employeur.
              </p>
            </div>
          </div>
        `},exportCSV:{enabled:!1,filename:"indemnites-kilometriques-estimation.csv",getCSVData:(s,i)=>{const e=s.data;return{headers:["Paramètre","Valeur"],rows:[["Type de véhicule",e.typeVehicule==="voiture"?"Voiture":"Deux-roues"],["Distance annuelle (km)",e.kilometres],["Indemnité par km (€)",e.indemniteParKm.toFixed(3)],["Indemnités totales (€)",e.total],...e.puissance?[["Puissance fiscale",e.puissance]]:[],...e.cylindree?[["Cylindrée",e.cylindree.replace("_"," ")]]:[]]}}}};document.addEventListener("DOMContentLoaded",()=>{setTimeout(()=>{var t,r;const s=document.getElementById("type_vehicule"),i=(t=document.getElementById("puissance"))==null?void 0:t.closest("div"),e=(r=document.getElementById("cylindree_moto"))==null?void 0:r.closest("div");function n(){const l=s==null?void 0:s.value;i&&(i.style.display=l==="voiture"?"block":"none"),e&&(e.style.display=l==="deux_roues"?"block":"none")}s==null||s.addEventListener("change",n),n()},100)});new c("ik-calculator",d);
