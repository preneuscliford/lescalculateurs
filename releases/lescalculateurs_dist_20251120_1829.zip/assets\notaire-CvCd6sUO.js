var B=Object.defineProperty;var F=(l,e,t)=>e in l?B(l,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):l[e]=t;var C=(l,e,t)=>F(l,typeof e!="symbol"?e+"":e,t);import{f as b}from"./main-C11GuAlR.js";import{C as L}from"./CalculatorFrame-CeXK84kH.js";import{b as S}from"./baremes-BY9f5jXV.js";import{_ as D}from"./chunk-jspdf-BCzl2gSH.js";import"./autoExportInit-DC5gTcqy.js";const M={title:"Calculateur de frais de notaire 2025",description:"Calculez vos frais de notaire selon les barèmes officiels en vigueur.",fields:[{id:"type_bien",label:"Type de bien immobilier *",type:"select",required:!0,options:[{value:"ancien",label:"Acquisition d'un bien ancien"},{value:"neuf",label:"Acquisition d'un bien neuf"},{value:"terrain",label:"Acquisition d'un terrain"}]},{id:"departement",label:"Département du bien *",type:"select",required:!0,options:[{value:"75",label:"75 - Paris (5.9%)"},{value:"92",label:"92 - Hauts-de-Seine (5.9%)"},{value:"93",label:"93 - Seine-Saint-Denis (5.9%)"},{value:"94",label:"94 - Val-de-Marne (5.9%)"},{value:"78",label:"78 - Yvelines (5.9%)"},{value:"91",label:"91 - Essonne (5.9%)"},{value:"95",label:"95 - Val-d'Oise (5.9%)"},{value:"77",label:"77 - Seine-et-Marne (5.8%)"},{value:"13",label:"13 - Bouches-du-Rhône (5.8%)"},{value:"69",label:"69 - Rhône (5.8%)"},{value:"59",label:"59 - Nord (5.8%)"},{value:"06",label:"06 - Alpes-Maritimes (5.8%)"},{value:"31",label:"31 - Haute-Garonne (5.8%)"},{value:"33",label:"33 - Gironde (5.8%)"},{value:"44",label:"44 - Loire-Atlantique (5.8%)"},{value:"34",label:"34 - Hérault (5.8%)"},{value:"67",label:"67 - Bas-Rhin (5.8%)"},{value:"35",label:"35 - Ille-et-Vilaine (5.8%)"},{value:"38",label:"38 - Isère (5.8%)"},{value:"83",label:"83 - Var (5.8%)"},{value:"62",label:"62 - Pas-de-Calais (5.8%)"},{value:"76",label:"76 - Seine-Maritime (5.8%)"},{value:"84",label:"84 - Vaucluse (5.8%)"},{value:"30",label:"30 - Gard (5.8%)"},{value:"17",label:"17 - Charente-Maritime (5.8%)"},{value:"2A",label:"2A - Corse-du-Sud (4.5%)"},{value:"2B",label:"2B - Haute-Corse (4.5%)"},{value:"autre",label:"Autre département (5.8%)"}]},{id:"prix_achat",label:"Prix d'acquisition *",type:"number",required:!0,placeholder:"250000",min:1e3,step:1e3,suffix:"€"},{id:"montant_mobilier",label:"Dont montant du mobilier (optionnel)",type:"number",placeholder:"0",min:0,step:500,suffix:"€"},{id:"type_emprunt",label:"Type d'emprunt",type:"select",options:[{value:"sans",label:"Sans emprunt"},{value:"sans_garantie",label:"Emprunt sans garantie hypothécaire"},{value:"avec_garantie",label:"Emprunt avec garantie hypothécaire"}]},{id:"remise_notaire_var",label:"Appliquer remise notariale sur la partie variable (-10%)",type:"checkbox"},{id:"prets_aides",label:"Montant des prêts PTZ, PEL, CEL et prêts aidés (optionnel)",type:"number",placeholder:"0",min:0,step:1e3,suffix:"€"},{id:"autres_prets",label:"Montant des autres prêts (optionnel)",type:"number",placeholder:"0",min:0,step:1e3,suffix:"€"}],calculate:l=>{try{const e=l.prix_achat||0,t=l.montant_mobilier||0,i=l.type_bien,r=l.departement,u=l.type_emprunt||"sans",s=l.prets_aides||0,o=l.autres_prets||0,c=l.remise_notaire_var===!0,n=e-t,p=s+o;let m=0,a=n;for(const A of S.notaire.tranches){if(a<=0)break;const $=Math.min(a,A.max-A.min);m+=$*A.taux,a-=$}c&&(m=m*.9);const d=new Set(["75","92","93","94","78","91","95"]),h=new Set(["2A","2B"]),g=d.has(r)?.059:h.has(r)?.045:.058,f={tauxDroits:g,fraisDivers:S.notaire.fraisDivers};let y=f.fraisDivers.cadastre+f.fraisDivers.conservation+f.fraisDivers.formalites,v=0;u==="avec_garantie"&&p>0?v=Math.max(375,p*.015):u==="sans_garantie"&&p>0&&(v=150);let x=0;i==="ancien"||i==="terrain"?x=n*g:i==="neuf"&&(x=0);let w=0;i==="terrain"&&(w=100);const T=(m+y+v+w)*S.notaire.tva,I=m+y+v+w+x+T,_=I/e*100;return{success:!0,data:{emoluments:m,fraisDivers:y,fraisHypotheque:v,fraisTerrain:w,droitsEnregistrement:x,tva:T,total:I,pourcentage:_,prixAchat:e,prixNetImmobilier:n,montantMobilier:t,typeBien:i,departement:r,typeEmprunt:u,montantTotalPrets:p,remiseVar:c}}}catch{return{success:!1,error:"Erreur lors du calcul. Vérifiez vos données."}}},formatResult:l=>{const e=l.data;return`
          <div class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div class="bg-blue-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800">Prix d'acquisition</h4>
                <p class="text-xl font-bold text-blue-600">${b(e.prixAchat)}</p>
                ${e.montantMobilier>0?`<p class="text-sm text-gray-600">Dont mobilier : ${b(e.montantMobilier)}</p>`:""}
              </div>
              <div class="bg-green-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800">Frais de notaire totaux</h4>
                <p class="text-xl font-bold text-green-600">${b(e.total)}</p>
                <p class="text-sm text-gray-600">${e.pourcentage.toFixed(2)}% du prix d'acquisition</p>
              </div>
            </div>

            <div class="bg-gray-50 p-4 rounded-lg">
              <h4 class="font-semibold text-gray-800 mb-3">Informations de l'acquisition :</h4>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                <div><span class="font-medium">Type de bien :</span> ${e.typeBien==="ancien"?"Bien ancien":e.typeBien==="neuf"?"Bien neuf":"Terrain"}</div>
                <div><span class="font-medium">Département :</span> ${e.departement}</div>
                <div><span class="font-medium">Prix net immobilier :</span> ${b(e.prixNetImmobilier)}</div>
                <div><span class="font-medium">Type d'emprunt :</span> ${e.typeEmprunt==="sans"?"Sans emprunt":e.typeEmprunt==="sans_garantie"?"Sans garantie hypothécaire":"Avec garantie hypothécaire"}</div>
                ${e.montantTotalPrets>0?`<div><span class="font-medium">Montant total des prêts :</span> ${b(e.montantTotalPrets)}</div>`:""}
                ${e.remiseVar?'<div><span class="font-medium">Remise notariale appliquée :</span> Oui (-10% sur la partie variable)</div>':""}
              </div>
            </div>
            
            <div class="border-t pt-4">
              <h4 class="font-semibold text-gray-800 mb-3">Détail des frais :</h4>
              <div class="space-y-2 text-sm">
                <div class="flex justify-between">
                  <span>Émoluments du notaire :</span>
                  <span class="font-medium">${b(e.emoluments)}</span>
                </div>
                ${e.droitsEnregistrement>0?`
                <div class="flex justify-between">
                  <span>Droits d'enregistrement :</span>
                  <span class="font-medium">${b(e.droitsEnregistrement)}</span>
                </div>
                `:""}
                <div class="flex justify-between">
                  <span>Frais divers (cadastre, conservation...) :</span>
                  <span class="font-medium">${b(e.fraisDivers)}</span>
                </div>
                ${e.fraisHypotheque>0?`
                <div class="flex justify-between">
                  <span>Frais d'hypothèque :</span>
                  <span class="font-medium">${b(e.fraisHypotheque)}</span>
                </div>
                `:""}
                ${e.fraisTerrain>0?`
                <div class="flex justify-between">
                  <span>Frais spécifiques terrain :</span>
                  <span class="font-medium">${b(e.fraisTerrain)}</span>
                </div>
                `:""}
                <div class="flex justify-between">
                  <span>TVA (${(S.notaire.tva*100).toFixed(1)}%) :</span>
                  <span class="font-medium">${b(e.tva)}</span>
                </div>
                <div class="flex justify-between border-t pt-2 font-semibold text-lg">
                  <span>Total frais de notaire :</span>
                  <span class="text-green-600">${b(e.total)}</span>
                </div>
              </div>
            </div>

            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mt-4">
              <p class="text-sm text-yellow-800">
                <strong>Information :</strong> Cette estimation est basée sur les barèmes officiels 2024-2025. 
                Le montant exact peut varier selon la complexité du dossier, les prestations complémentaires 
                et les taux locaux (droits de mutation variables selon les départements).
              </p>
            </div>
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
              <p class="text-sm text-blue-800">
                <strong>Bon à savoir :</strong> Les droits d'enregistrement peuvent varier selon votre localisation. 
                Contactez votre notaire pour une estimation précise.
              </p>
            </div>

            <!-- Bouton de partage du calcul -->
            <div class="mt-4 flex justify-center">
              <button
                type="button"
                id="btn-share-calc"
                class="bg-blue-600 text-white font-semibold px-4 py-2 rounded-md shadow hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-600"
                title="Copier/partager le lien du calcul"
              >🔗 Partager ce calcul</button>
            </div>

            <!-- Bouton Ajouter à la comparaison -->
            <div class="mt-6 flex justify-center">
              <button
                onclick="window.ajouterAComparaison?.()"
                class="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-3 px-8 rounded-lg shadow-lg transform hover:scale-105 transition-all duration-200 flex items-center gap-2"
              >
                <span class="text-xl">📊</span>
                <span>Comparer avec une autre ville</span>
              </button>
            </div>
          </div>
          `},exportCSV:{enabled:!0,filename:"frais_notaire_2025.csv",getCSVData:(l,e)=>{const t=l.data,i=n=>!n||isNaN(n)?" 0,00":" "+n.toLocaleString("fr-FR",{minimumFractionDigits:2,maximumFractionDigits:2}),r=n=>!n||isNaN(n)||!t.prixAchat?" 0,00%":" "+(n/t.prixAchat*100).toFixed(2)+"%",u={75:"75 - Paris",13:"13 - Bouches-du-Rhône",69:"69 - Rhône",59:"59 - Nord",92:"92 - Hauts-de-Seine",93:"93 - Seine-Saint-Denis",94:"94 - Val-de-Marne",77:"77 - Seine-et-Marne",78:"78 - Yvelines",91:"91 - Essonne",95:"95 - Val-d'Oise","06":"06 - Alpes-Maritimes",31:"31 - Haute-Garonne",33:"33 - Gironde",44:"44 - Loire-Atlantique",34:"34 - Hérault",67:"67 - Bas-Rhin",35:"35 - Ille-et-Vilaine",38:"38 - Isère",83:"83 - Var",autre:"Autre département"},s=t.typeBien==="ancien"?"Bien ancien":t.typeBien==="neuf"?"Bien neuf":"Terrain",o=t.typeEmprunt==="sans"?"Sans emprunt":t.typeEmprunt==="sans_garantie"?"Sans garantie hypothécaire":"Avec garantie hypothécaire",c=u[t.departement]||t.departement;return{headers:["Description","Montant (€)","Pourcentage du prix"],rows:[["--- INFORMATIONS ---","",""],["Type de bien",s,""],["Département",c,""],["Prix net immobilier",i(t.prixNetImmobilier),""],["Type d'emprunt",o,""],["","",""],["--- CALCUL DES FRAIS ---","",""],["Prix d'acquisition",i(t.prixAchat)," 100%"],["Émoluments du notaire",i(t.emoluments),r(t.emoluments)],["Droits d'enregistrement",i(t.droitsEnregistrement),r(t.droitsEnregistrement)],["Frais divers (cadastre...)",i(t.fraisDivers),r(t.fraisDivers)],...t.fraisHypotheque>0?[["Frais d'hypothèque",i(t.fraisHypotheque),r(t.fraisHypotheque)]]:[],...t.fraisTerrain>0?[["Frais spécifiques terrain",i(t.fraisTerrain),r(t.fraisTerrain)]]:[],["TVA (20%)",i(t.tva),r(t.tva)],["","",""],["TOTAL FRAIS DE NOTAIRE",i(t.total),r(t.total)]]}}},exportXLSX:{enabled:!0,filename:"frais_notaire_2025.xlsx",getXLSXData:(l,e)=>{const t=l.data,i=n=>" "+(n&&!isNaN(n)?Number(n):0).toLocaleString("fr-FR",{minimumFractionDigits:2,maximumFractionDigits:2}),r=n=>{const p=t.prixAchat&&!isNaN(t.prixAchat)?Number(t.prixAchat):0,m=n&&!isNaN(n)?Number(n):0;return" "+(p>0?m/p*100:0).toLocaleString("fr-FR",{minimumFractionDigits:2,maximumFractionDigits:2})+"%"},u={75:"75 - Paris",13:"13 - Bouches-du-Rhône",69:"69 - Rhône",59:"59 - Nord",92:"92 - Hauts-de-Seine",93:"93 - Seine-Saint-Denis",94:"94 - Val-de-Marne",77:"77 - Seine-et-Marne",78:"78 - Yvelines",91:"91 - Essonne",95:"95 - Val-d'Oise","06":"06 - Alpes-Maritimes",31:"31 - Haute-Garonne",33:"33 - Gironde",44:"44 - Loire-Atlantique",34:"34 - Hérault",67:"67 - Bas-Rhin",35:"35 - Ille-et-Vilaine",38:"38 - Isère",83:"83 - Var",autre:"Autre département"},s=t.typeBien==="ancien"?"Bien ancien":t.typeBien==="neuf"?"Bien neuf":"Terrain",o=t.typeEmprunt==="sans"?"Sans emprunt":t.typeEmprunt==="sans_garantie"?"Sans garantie hypothécaire":"Avec garantie hypothécaire",c=u[t.departement]||t.departement;return{headers:["Description","Montant (€)","Pourcentage du prix"],rows:[["--- INFORMATIONS ---","",""],["Type de bien",s,""],["Département",c,""],["Prix net immobilier",i(t.prixNetImmobilier),""],["Type d'emprunt",o,""],["","",""],["--- CALCUL DES FRAIS ---","",""],["Prix d'acquisition",i(t.prixAchat)," 100%"],["Émoluments du notaire",i(t.emoluments),r(t.emoluments)],["Droits d'enregistrement",i(t.droitsEnregistrement),r(t.droitsEnregistrement)],["Frais divers (cadastre...)",i(t.fraisDivers),r(t.fraisDivers)],...t.fraisHypotheque>0?[["Frais d'hypothèque",i(t.fraisHypotheque),r(t.fraisHypotheque)]]:[],...t.fraisTerrain>0?[["Frais spécifiques terrain",i(t.fraisTerrain),r(t.fraisTerrain)]]:[],["TVA (20%)",i(t.tva),r(t.tva)],["","",""],["TOTAL FRAIS DE NOTAIRE",i(t.total),r(t.total)]]}}}};new L("notaire-calculator",M);class P{constructor(e){C(this,"calculs",[]);C(this,"maxComparaisons",4);C(this,"containerId");C(this,"currentChart",null);C(this,"currentChartId","");this.containerId=e,this.loadFromStorage()}ajouterCalcul(e,t,i){if(this.calculs.length>=this.maxComparaisons){alert(`Vous ne pouvez comparer que ${this.maxComparaisons} villes maximum`);return}if(this.calculs.some(s=>s.departement===t.departement))if(confirm(`Le département "${i}" est déjà dans la comparaison.

Voulez-vous le remplacer par ce nouveau calcul ?`))this.calculs=this.calculs.filter(s=>s.departement!==t.departement);else return;const u={id:`calcul-${Date.now()}`,timestamp:Date.now(),departement:t.departement,departementLabel:i,typeBien:t.type_bien,prixAchat:e.data.prixAchat,prixNetImmobilier:e.data.prixNetImmobilier,montantMobilier:e.data.montantMobilier||0,typeEmprunt:t.type_emprunt,montantTotalPrets:e.data.montantTotalPrets||0,emoluments:e.data.emoluments,droitsEnregistrement:e.data.droitsEnregistrement,fraisDivers:e.data.fraisDivers,fraisHypotheque:e.data.fraisHypotheque||0,fraisTerrain:e.data.fraisTerrain||0,tva:e.data.tva,total:e.data.total,pourcentage:e.data.pourcentage};this.calculs.push(u),this.afficherComparaison(),this.saveToStorage()}supprimerCalcul(e){this.calculs=this.calculs.filter(t=>t.id!==e),this.saveToStorage(),this.calculs.length===0?this.masquerComparaison():this.afficherComparaison()}afficherComparaison(){const e=document.getElementById(this.containerId);e&&(e.innerHTML=this.genererHTML(),e.classList.remove("hidden"),this.creerGraphique())}saveToStorage(){try{localStorage.setItem("comparaison_notaires",JSON.stringify(this.calculs))}catch{}}loadFromStorage(){try{const e=localStorage.getItem("comparaison_notaires");if(!e)return;const t=JSON.parse(e);Array.isArray(t)&&(this.calculs=t,this.calculs.length>0&&this.afficherComparaison())}catch{}}masquerComparaison(){const e=document.getElementById(this.containerId);e&&e.classList.add("hidden")}reinitialiser(){try{this.calculs=[],localStorage.removeItem("comparaison_notaires");const e=document.getElementById(this.containerId);e&&(e.innerHTML=""),this.masquerComparaison()}catch{}}creerGraphique(){this.currentChart&&(this.currentChart.destroy(),this.currentChart=null),`${this.currentChartId}`;const e=document.querySelector('canvas[id^="chart-"]');if(!e){console.error("Canvas non trouvé pour le graphique");return}const t=e.getContext("2d");if(!t)return;const i=this.calculs.map(a=>a.departementLabel.split(" (")[0]),r=this.calculs.map(a=>a.total),u=Math.min(...r),s=[{bg:"rgba(59, 130, 246, 0.8)",border:"rgba(59, 130, 246, 1)"},{bg:"rgba(147, 51, 234, 0.8)",border:"rgba(147, 51, 234, 1)"},{bg:"rgba(236, 72, 153, 0.8)",border:"rgba(236, 72, 153, 1)"},{bg:"rgba(249, 115, 22, 0.8)",border:"rgba(249, 115, 22, 1)"}],o={bg:"rgba(34, 197, 94, 0.8)",border:"rgba(34, 197, 94, 1)"},c=r.map((a,d)=>a===u?o.bg:s[d%s.length].bg),n=r.map((a,d)=>a===u?o.border:s[d%s.length].border);D(async()=>{const{Chart:a,BarController:d,BarElement:h,CategoryScale:g,LinearScale:f,Tooltip:y,Legend:v}=await import("./chunk-chart-Y1OVfVMf.js");return{Chart:a,BarController:d,BarElement:h,CategoryScale:g,LinearScale:f,Tooltip:y,Legend:v}},[]).then(({Chart:a,BarController:d,BarElement:h,CategoryScale:g,LinearScale:f,Tooltip:y,Legend:v})=>{a.register(d,h,g,f,y,v),a.defaults.devicePixelRatio=Math.max(1,Math.ceil(window.devicePixelRatio||1)),this.currentChart=new a(t,{type:"bar",data:{labels:i,datasets:[{label:"Frais de notaire totaux (€)",data:r,backgroundColor:c,borderColor:n,borderWidth:2,borderRadius:8,barThickness:60}]},options:{responsive:!0,maintainAspectRatio:!1,animation:!1,plugins:{legend:{display:!1},tooltip:{callbacks:{label:x=>{const w=x.parsed.y,E=this.calculs[x.dataIndex];return[`Total : ${w.toLocaleString("fr-FR",{style:"currency",currency:"EUR",minimumFractionDigits:0,maximumFractionDigits:0})}`,`Soit ${E.pourcentage.toFixed(2)}% du prix`]}},backgroundColor:"rgba(0, 0, 0, 0.8)",padding:12,titleFont:{size:14},bodyFont:{size:13}}},scales:{y:{beginAtZero:!0,ticks:{callback:x=>x.toLocaleString("fr-FR")+" €",font:{size:12}},grid:{color:"rgba(0, 0, 0, 0.05)"}},x:{ticks:{font:{size:12,weight:"bold"}},grid:{display:!1}}}}})});const p=document.getElementById("btn-download-chart-png"),m=document.getElementById("btn-download-chart-pdf");p==null||p.addEventListener("click",()=>this.telechargerBlocPNG()),m==null||m.addEventListener("click",()=>this.telechargerBlocPDF())}genererHTML(){const e=a=>new Intl.NumberFormat("fr-FR",{style:"currency",currency:"EUR",minimumFractionDigits:0,maximumFractionDigits:0}).format(a),t=a=>new Intl.NumberFormat("fr-FR",{style:"currency",currency:"EUR",minimumFractionDigits:2,maximumFractionDigits:2}).format(a),i=a=>a==="ancien"?"Bien ancien":a==="neuf"?"Bien neuf":"Terrain",r=Math.min(...this.calculs.map(a=>a.total)),u=Math.max(...this.calculs.map(a=>a.total)),s=this.calculs.map(a=>a.prixAchat),o=s.length>0&&s.every(a=>a===s[0]),c=s[0]??0,n=s.length?Math.min(...s):0,p=s.length?Math.max(...s):0;this.currentChartId=Date.now().toString();const m=`chart-${this.currentChartId}`;return`
      <div class="bg-white border-2 border-blue-500 rounded-lg p-6 mt-6">
        <div class="flex justify-between items-start mb-4">
          <div>
            <h3 class="text-xl font-bold text-gray-900">📊 Comparaison des frais de notaire</h3>
            <div class="mt-1 text-sm text-gray-700">
              ${o?`Pour un prix d'acquisition de <span class="font-semibold">${t(c)}</span>`:s.length>0?`Pour des prix d'acquisition de <span class="font-semibold">${t(n)}</span> à <span class="font-semibold">${t(p)}</span>`:""}
            </div>
          </div>
          <div data-export-exclude="true">
            <button 
              onclick="window.comparaisonNotaire?.reinitialiser()"
              class="text-sm text-red-600 hover:text-red-700 font-medium"
            >
              🗑️ Tout effacer
            </button>
          </div>
        </div>

        <!-- Graphique Chart.js -->
        <div class="mb-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-5">
          <h4 class="text-base font-semibold text-gray-800 mb-4 text-center">
            📈 Comparatif visuel des frais totaux
          </h4>
          <div class="max-w-4xl mx-auto" style="height: 360px;">
            <canvas id="${m}"></canvas>
          </div>
          ${this.calculs.length>1?`
          <div class="mt-4 text-center text-sm text-gray-600">
            💡 Économie maximale possible : <span class="font-bold text-green-600">${e(u-r)}</span>
          </div>
          `:""}
          <div class="mt-4 flex justify-center gap-3" data-export-exclude="true">
            <button id="btn-download-chart-png" class="bg-white border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 px-4 py-2">🖼️ Télécharger en PNG</button>
            <button id="btn-download-chart-pdf" class="bg-white border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 px-4 py-2">📄 Télécharger en PDF</button>
          </div>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-sm">
            <thead>
              <tr class="bg-gray-100">
                <th class="text-left p-3 font-semibold">Critère</th>
                ${this.calculs.map((a,d)=>`
                  <th class="text-center p-3 font-semibold relative">
                    <div>${a.departementLabel}</div>
                    <button 
                      onclick="window.comparaisonNotaire?.supprimerCalcul('${a.id}')"
                      class="absolute top-2 right-2 text-red-500 hover:text-red-700"
                      title="Supprimer"
                    >
                      ✕
                    </button>
                  </th>
                `).join("")}
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
              <!-- Type de bien -->
              <tr class="hover:bg-gray-50">
                <td class="p-3 font-medium">Type de bien</td>
                ${this.calculs.map(a=>`
                  <td class="p-3 text-center">${i(a.typeBien)}</td>
                `).join("")}
              </tr>

              <!-- Prix d'acquisition -->
              <tr class="hover:bg-gray-50 bg-blue-50">
                <td class="p-3 font-medium">Prix d'acquisition</td>
                ${this.calculs.map(a=>`
                  <td class="p-3 text-center font-semibold">${e(a.prixAchat)}</td>
                `).join("")}
              </tr>

              <!-- Émoluments -->
              <tr class="hover:bg-gray-50">
                <td class="p-3">Émoluments du notaire</td>
                ${this.calculs.map(a=>`
                  <td class="p-3 text-center">${e(a.emoluments)}</td>
                `).join("")}
              </tr>

              <!-- Droits d'enregistrement -->
              <tr class="hover:bg-gray-50">
                <td class="p-3">Droits d'enregistrement</td>
                ${this.calculs.map(a=>`
                  <td class="p-3 text-center ${a.droitsEnregistrement===Math.min(...this.calculs.map(d=>d.droitsEnregistrement))?"text-green-600 font-semibold":""}">${e(a.droitsEnregistrement)}</td>
                `).join("")}
              </tr>

              <!-- Frais divers -->
              <tr class="hover:bg-gray-50">
                <td class="p-3">Frais divers</td>
                ${this.calculs.map(a=>`
                  <td class="p-3 text-center">${e(a.fraisDivers)}</td>
                `).join("")}
              </tr>

              ${this.calculs.some(a=>a.fraisHypotheque>0)?`
              <tr class="hover:bg-gray-50">
                <td class="p-3">Frais d'hypothèque</td>
                ${this.calculs.map(a=>`
                  <td class="p-3 text-center">${a.fraisHypotheque>0?e(a.fraisHypotheque):"-"}</td>
                `).join("")}
              </tr>
              `:""}

              <!-- TVA -->
              <tr class="hover:bg-gray-50">
                <td class="p-3">TVA (20%)</td>
                ${this.calculs.map(a=>`
                  <td class="p-3 text-center">${e(a.tva)}</td>
                `).join("")}
              </tr>

              <!-- TOTAL -->
              <tr class="bg-green-50 font-bold">
                <td class="p-3">TOTAL FRAIS DE NOTAIRE</td>
                ${this.calculs.map(a=>`
                  <td class="p-3 text-center ${a.total===Math.min(...this.calculs.map(d=>d.total))?"text-green-600 text-lg":"text-gray-900"}">${e(a.total)}</td>
                `).join("")}
              </tr>

              <!-- Pourcentage -->
              <tr class="bg-green-50">
                <td class="p-3">% du prix d'acquisition</td>
                ${this.calculs.map(a=>`
                  <td class="p-3 text-center font-semibold">${a.pourcentage.toFixed(2)}%</td>
                `).join("")}
              </tr>

              <!-- Économie potentielle -->
              ${this.calculs.length>1?`
              <tr class="bg-yellow-50">
                <td class="p-3 font-semibold">💰 Économie vs le moins cher</td>
                ${this.calculs.map(a=>{const d=Math.min(...this.calculs.map(g=>g.total)),h=a.total-d;return`
                  <td class="p-3 text-center font-semibold ${h===0?"text-green-600":"text-orange-600"}">
                    ${h===0?"✓ Le moins cher !":`+ ${e(h)}`}
                  </td>
                `}).join("")}
              </tr>
              `:""}
            </tbody>
          </table>
        </div>

        ${this.calculs.length<this.maxComparaisons?`
        <div class="mt-6 flex flex-col items-center gap-3" data-export-exclude="true">
          <button
            onclick="window.ouvrirModaleComparaison?.()"
            class="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-3 px-8 rounded-lg shadow-lg transform hover:scale-105 transition-all duration-200 flex items-center gap-2"
          >
            <span class="text-xl">➕</span>
            <span>Ajouter une autre ville</span>
          </button>
          <p class="text-sm text-gray-600">
            💡 Vous pouvez ajouter jusqu'à ${this.maxComparaisons-this.calculs.length} ville${this.maxComparaisons-this.calculs.length>1?"s":""} supplémentaire${this.maxComparaisons-this.calculs.length>1?"s":""}
          </p>
        </div>
        `:`
        <div class="mt-4 text-center text-sm text-gray-600" data-export-exclude="true">
          ⚠️ Limite de ${this.maxComparaisons} comparaisons atteinte
        </div>
        `}
      </div>
    `}async telechargerBlocPNG(){try{const e=document.getElementById(this.containerId);if(!e)return;const{default:t}=await D(async()=>{const{default:c}=await import("./chunk-html2canvas-CBrSDip1.js");return{default:c}},[]),i=Array.from(document.querySelectorAll('[data-export-exclude="true"]')),r=i.map(c=>c.style.display||"");i.forEach(c=>c.style.display="none");const u=await t(e,{useCORS:!0,scale:Math.max(2,Math.ceil(window.devicePixelRatio||1)),backgroundColor:"#ffffff",logging:!1});i.forEach((c,n)=>c.style.display=r[n]);const s=u.toDataURL("image/png"),o=document.createElement("a");o.href=s,o.download=`bloc-comparaison-frais-notaire-${Date.now()}.png`,document.body.appendChild(o),o.click(),document.body.removeChild(o)}catch{}}async telechargerBlocPDF(){try{const e=document.getElementById(this.containerId);if(!e)return;const{default:t}=await D(async()=>{const{default:a}=await import("./chunk-html2canvas-CBrSDip1.js");return{default:a}},[]),{jsPDF:i}=await D(async()=>{const{jsPDF:a}=await import("./chunk-jspdf-BCzl2gSH.js").then(d=>d.j);return{jsPDF:a}},[]),r=Array.from(document.querySelectorAll('[data-export-exclude="true"]')),u=r.map(a=>a.style.display||"");r.forEach(a=>a.style.display="none");const s=await t(e,{useCORS:!0,scale:Math.max(2,Math.ceil(window.devicePixelRatio||1)),backgroundColor:"#ffffff",logging:!1});r.forEach((a,d)=>a.style.display=u[d]);const o=new i("p","mm","a4"),c=o.internal.pageSize.getWidth()-20,n=s.height*c/s.width,p=o.internal.pageSize.getHeight();let m=10;if(n>p-m-10){let a=n,d=0;for(;a>0;){const h=Math.min(a,p-m-10),g=h*s.height/n,f=document.createElement("canvas");f.width=s.width,f.height=g;const y=f.getContext("2d");if(!y)break;y.drawImage(s,0,d,s.width,g,0,0,s.width,g);const v=f.toDataURL("image/png");o.addImage(v,"PNG",10,m,c,h),a-=h,d+=g,a>0&&(o.addPage(),m=10)}}else{const a=s.toDataURL("image/png");o.addImage(a,"PNG",10,m,c,n)}o.save(`bloc-comparaison-frais-notaire-${Date.now()}.pdf`)}catch{}}telechargerGraphiquePNG(){try{const e=document.querySelector('canvas[id^="chart-"]');if(!e)return;const t=e.toDataURL("image/png"),i=document.createElement("a");i.href=t,i.download=`comparaison-frais-notaire-${Date.now()}.png`,document.body.appendChild(i),i.click(),document.body.removeChild(i)}catch{}}async telechargerGraphiquePDF(){try{const e=document.querySelector('canvas[id^="chart-"]');if(!e)return;const t=e.toDataURL("image/png"),{jsPDF:i}=await D(async()=>{const{jsPDF:a}=await import("./chunk-jspdf-BCzl2gSH.js").then(d=>d.j);return{jsPDF:a}},[]),r=new i("p","mm","a4"),u=r.internal.pageSize.getWidth(),s=r.internal.pageSize.getHeight(),o=10,c=u-o*2,n=e.height*c/e.width;let p=o;if(n>s-o*2){const a=(s-o*2)/n,d=c*a,h=n*a;r.addImage(t,"PNG",(u-d)/2,p,d,h)}else r.addImage(t,"PNG",o,p,c,n);const m=`comparaison-frais-notaire-${Date.now()}.pdf`;r.save(m)}catch{}}getNombreCalculs(){return this.calculs.length}exporterCSV(){const e=r=>" "+r.toLocaleString("fr-FR",{minimumFractionDigits:2,maximumFractionDigits:2}),t=["Critère",...this.calculs.map(r=>r.departementLabel)],i=[["Type de bien",...this.calculs.map(r=>r.typeBien==="ancien"?"Bien ancien":r.typeBien==="neuf"?"Bien neuf":"Terrain")],["Prix d'acquisition",...this.calculs.map(r=>e(r.prixAchat))],["",...this.calculs.map(()=>"")],["Émoluments du notaire",...this.calculs.map(r=>e(r.emoluments))],["Droits d'enregistrement",...this.calculs.map(r=>e(r.droitsEnregistrement))],["Frais divers",...this.calculs.map(r=>e(r.fraisDivers))],...this.calculs.some(r=>r.fraisHypotheque>0)?[["Frais d'hypothèque",...this.calculs.map(r=>r.fraisHypotheque>0?e(r.fraisHypotheque):"-")]]:[],["TVA (20%)",...this.calculs.map(r=>e(r.tva))],["",...this.calculs.map(()=>"")],["TOTAL FRAIS DE NOTAIRE",...this.calculs.map(r=>e(r.total))],["% du prix",...this.calculs.map(r=>` ${r.pourcentage.toFixed(2)}%`)]];return{headers:t,rows:i}}}window.comparaisonNotaire=new P("comparaison-container");let q=!1;window.ouvrirModaleComparaison=()=>{const l=document.getElementById("modal-selection-ville");l&&(l.style.display="flex")};window.ajouterAComparaison=()=>{if(q)return;const l=window.dernierCalculNotaire;if(l&&l.result&&l.values){const i={75:"75 - Paris (5.9%)",92:"92 - Hauts-de-Seine (5.9%)",93:"93 - Seine-Saint-Denis (5.9%)",94:"94 - Val-de-Marne (5.9%)",78:"78 - Yvelines (5.9%)",91:"91 - Essonne (5.9%)",95:"95 - Val-d'Oise (5.9%)",77:"77 - Seine-et-Marne (5.8%)",13:"13 - Bouches-du-Rhône (5.8%)",69:"69 - Rhône (5.8%)",59:"59 - Nord (5.8%)","06":"06 - Alpes-Maritimes (5.8%)",31:"31 - Haute-Garonne (5.8%)",33:"33 - Gironde (5.8%)",44:"44 - Loire-Atlantique (5.8%)",34:"34 - Hérault (5.8%)",67:"67 - Bas-Rhin (5.8%)",35:"35 - Ille-et-Vilaine (5.8%)",38:"38 - Isère (5.8%)",83:"83 - Var (5.8%)",62:"62 - Pas-de-Calais (5.8%)",76:"76 - Seine-Maritime (5.8%)",84:"84 - Vaucluse (5.8%)",30:"30 - Gard (5.8%)",17:"17 - Charente-Maritime (5.8%)","2A":"2A - Corse-du-Sud (4.5%)","2B":"2B - Haute-Corse (4.5%)",autre:"Autre département (5.8%)"}[l.values.departement]||l.values.departement;window.comparaisonNotaire.ajouterCalcul(l.result,l.values,i),q=!0;const r=document.querySelector('button[onclick*="ajouterAComparaison"]');r&&(r.disabled=!0,r.classList.remove("from-purple-600","to-blue-600","hover:from-purple-700","hover:to-blue-700","hover:scale-105"),r.classList.add("bg-gray-400","cursor-not-allowed","opacity-50"),r.innerHTML='<span class="text-xl">✓</span><span>Comparaison activée</span>')}const e=document.getElementById("modal-selection-ville");e&&(e.style.display="flex")};window.annulerSelectionVille=()=>{const l=document.getElementById("modal-selection-ville");l&&(l.style.display="none")};window.confirmerSelectionVille=()=>{const e=document.getElementById("modal-departement").value;if(!e){alert("Veuillez sélectionner un département");return}const t=document.getElementById("modal-selection-ville");t&&(t.style.display="none");const i=window.dernierCalculNotaire;if(!i||!i.values){alert("Erreur : impossible de récupérer les données du calcul");return}const r=document.getElementById("departement");r&&(r.value=e);const u={...i.values};u.departement=e,Object.keys(u).forEach(s=>{const o=document.getElementById(s);o&&(o.type==="checkbox"?o.checked=u[s]:o.value=u[s])}),setTimeout(()=>{const s=document.querySelector("#notaire-calculator form"),o=s==null?void 0:s.querySelector('button[type="submit"]');o&&(o.click(),setTimeout(()=>{var n;const c=window.dernierCalculNotaire;if(c&&c.result&&c.values){const m={75:"75 - Paris (5.9%)",92:"92 - Hauts-de-Seine (5.9%)",93:"93 - Seine-Saint-Denis (5.9%)",94:"94 - Val-de-Marne (5.9%)",78:"78 - Yvelines (5.9%)",91:"91 - Essonne (5.9%)",95:"95 - Val-d'Oise (5.9%)",77:"77 - Seine-et-Marne (5.8%)",13:"13 - Bouches-du-Rhône (5.8%)",69:"69 - Rhône (5.8%)",59:"59 - Nord (5.8%)","06":"06 - Alpes-Maritimes (5.8%)",31:"31 - Haute-Garonne (5.8%)",33:"33 - Gironde (5.8%)",44:"44 - Loire-Atlantique (5.8%)",34:"34 - Hérault (5.8%)",67:"67 - Bas-Rhin (5.8%)",35:"35 - Ille-et-Vilaine (5.8%)",38:"38 - Isère (5.8%)",83:"83 - Var (5.8%)",62:"62 - Pas-de-Calais (5.8%)",76:"76 - Seine-Maritime (5.8%)",84:"84 - Vaucluse (5.8%)",30:"30 - Gard (5.8%)",17:"17 - Charente-Maritime (5.8%)","2A":"2A - Corse-du-Sud (4.5%)","2B":"2B - Haute-Corse (4.5%)",autre:"Autre département (5.8%)"}[c.values.departement]||c.values.departement;window.comparaisonNotaire.ajouterCalcul(c.result,c.values,m),(n=document.getElementById("comparaison-container"))==null||n.scrollIntoView({behavior:"smooth",block:"start"})}},500))},100)};
