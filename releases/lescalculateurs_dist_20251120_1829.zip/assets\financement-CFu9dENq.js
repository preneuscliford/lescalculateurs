import"./main-C11GuAlR.js";import"./autoExportInit-DC5gTcqy.js";import"./chunk-jspdf-BCzl2gSH.js";document.getElementById("financement-form").addEventListener("submit",function(f){f.preventDefault();const y=parseFloat(document.getElementById("salaire").value)||0,h=parseFloat(document.getElementById("autresRevenus").value)||0,E=parseFloat(document.getElementById("loyerPret").value)||0,I=parseFloat(document.getElementById("autresCredits").value)||0,w=parseFloat(document.getElementById("assurances").value)||0,$=parseFloat(document.getElementById("chargesFixes").value)||0,m=document.getElementById("typeAchat").value,l=parseFloat(document.getElementById("prixTotal").value)||0,v=parseFloat(document.getElementById("apport").value)||0,a=parseInt(document.getElementById("dureeCredit").value),F=parseFloat(document.getElementById("tauxInteret").value);if(!y||!l){alert("Veuillez saisir au minimum votre salaire et le prix de votre projet");return}if(v>=l){alert("Votre apport ne peut pas être supérieur ou égal au prix total");return}const r=y+h,i=E+I+w+$,s=l-v;let t=F;if(!t)switch(m){case"voiture":t=a<=48?4.5:5.2;break;case"travaux":t=3.8;break;case"electromenager":t=5.8;break;case"voyage":t=6.5;break;default:t=5}const g=t/100/12;let n=0;s>0&&(t===0?n=s/a:n=s*g*Math.pow(1+g,a)/(Math.pow(1+g,a)-1));const x=i+n,d=x/r*100,c=r-x,b=n*a,A=b-s;let o,u,p;d<=33?(o="✅ Viable",u="text-green-600",p="Votre projet est financièrement viable ! Vous respectez les critères bancaires."):d<=40?(o="⚠️ À risque",u="text-orange-600",p="Attention : endettement élevé. Réduisez vos charges ou augmentez votre apport."):(o="❌ Impossible",u="text-red-600",p="Projet non viable actuellement. Réduisez le montant ou augmentez vos revenus.");function e(C){return new Intl.NumberFormat("fr-FR",{style:"currency",currency:"EUR"}).format(C)}const B=`
          <div class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div class="bg-blue-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800">Revenus mensuels</h4>
                <p class="text-xl font-bold text-blue-600">${e(r)}</p>
              </div>
              <div class="bg-red-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800">Charges actuelles</h4>
                <p class="text-xl font-bold text-red-600">${e(i)}</p>
              </div>
            </div>

            <div class="bg-purple-50 border-l-4 border-purple-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-purple-900 mb-4">🎯 Résumé de votre projet</h3>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p class="text-sm text-gray-600">Type d'achat</p>
                  <p class="text-lg font-semibold text-gray-900">${m.charAt(0).toUpperCase()+m.slice(1)}</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Prix total</p>
                  <p class="text-lg font-semibold text-gray-900">${e(l)}</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Apport personnel</p>
                  <p class="text-lg font-semibold text-gray-900">${e(v)}</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Montant à emprunter</p>
                  <p class="text-lg font-semibold text-gray-900">${e(s)}</p>
                </div>
              </div>
            </div>

            ${s>0?`
            <div class="bg-green-50 border-l-4 border-green-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-green-900 mb-4">💰 Simulation de crédit</h3>
              <div class="space-y-3">
                <div class="flex justify-between">
                  <span class="text-gray-600">Durée :</span>
                  <span class="font-semibold">${a} mois</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Taux d'intérêt :</span>
                  <span class="font-semibold">${t.toFixed(2)}%</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Mensualité :</span>
                  <span class="font-semibold text-green-700">${e(n)}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Coût total du crédit :</span>
                  <span class="font-semibold">${e(A)}</span>
                </div>
                <div class="flex justify-between text-lg">
                  <span class="font-bold text-gray-900">Total à rembourser :</span>
                  <span class="font-bold text-green-700">${e(b)}</span>
                </div>
              </div>
            </div>
            `:`
            <div class="bg-green-50 border-l-4 border-green-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-green-900 mb-4">💰 Achat comptant</h3>
              <p class="text-green-700">Félicitations ! Votre apport couvre entièrement l'achat. Aucun crédit nécessaire.</p>
            </div>
            `}

            <div class="bg-gray-50 border-l-4 border-gray-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-gray-900 mb-4">📊 Analyse financière</h3>
              <div class="space-y-3">
                <div class="flex justify-between">
                  <span class="text-gray-600">Charges totales (avec crédit) :</span>
                  <span class="font-semibold">${e(x)}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Reste à vivre :</span>
                  <span class="font-semibold ${c>0?"text-green-600":"text-red-600"}">${e(c)}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Taux d'endettement :</span>
                  <span class="font-semibold">${d.toFixed(1)}%</span>
                </div>
                <div class="border-t pt-3 flex justify-between text-xl">
                  <span class="font-bold text-gray-900">Viabilité :</span>
                  <span class="font-bold ${u}">${o}</span>
                </div>
              </div>
            </div>

            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <p class="text-sm text-yellow-800">
                <strong>💡 Conseil :</strong> ${p}
              </p>
            </div>

            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p class="text-sm text-blue-800">
                <strong>📋 À retenir :</strong> Cette simulation est indicative. Les banques étudient chaque dossier individuellement selon vos revenus, situation professionnelle et historique bancaire.
              </p>
            </div>
          </div>
          `;window.financementData={revenusTotaux:r,chargesTotales:i,resteAVivre:c,tauxEndettementActuel:i/r*100,capaciteEmpruntMax:l,montantAEmprunter:s,mensualiteEstimee:n,coutTotalCredit:b,tauxEndettementFinal:d,resteAVivreFinal:c,faisabilite:o},document.getElementById("results").innerHTML=B,document.getElementById("results").classList.remove("hidden"),document.getElementById("results").scrollIntoView({behavior:"smooth"})});
