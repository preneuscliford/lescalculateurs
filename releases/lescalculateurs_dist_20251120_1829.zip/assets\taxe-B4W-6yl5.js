import{f as r}from"./main-C11GuAlR.js";import{C as b}from"./CalculatorFrame-CeXK84kH.js";import{b as s}from"./baremes-BY9f5jXV.js";import"./autoExportInit-DC5gTcqy.js";import"./chunk-jspdf-BCzl2gSH.js";const x={title:"Simulateur de taxe foncière 2025",description:"Estimez votre taxe foncière selon la valeur locative et les taux locaux.",fields:[{id:"valeur_locative",label:"Valeur locative cadastrale annuelle",type:"number",required:!0,placeholder:"8000",min:100,step:100},{id:"region",label:"Région",type:"select",required:!0,options:[{value:"ile_de_france",label:"Île-de-France"},{value:"provence_alpes_cote_azur",label:"Provence-Alpes-Côte d'Azur"},{value:"auvergne_rhone_alpes",label:"Auvergne-Rhône-Alpes"},{value:"occitanie",label:"Occitanie"},{value:"nouvelle_aquitaine",label:"Nouvelle-Aquitaine"},{value:"grand_est",label:"Grand Est"},{value:"hauts_de_france",label:"Hauts-de-France"},{value:"normandie",label:"Normandie"},{value:"centre_val_de_loire",label:"Centre-Val de Loire"},{value:"bourgogne_franche_comte",label:"Bourgogne-Franche-Comté"},{value:"pays_de_la_loire",label:"Pays de la Loire"},{value:"bretagne",label:"Bretagne"},{value:"corse",label:"Corse"}]},{id:"residence_principale",label:"Résidence principale",type:"checkbox"},{id:"age_proprietaire",label:"Âge du propriétaire (optionnel)",type:"number",placeholder:"45",min:18,max:120},{id:"handicape",label:"Propriétaire en situation de handicap",type:"checkbox"}],calculate:t=>{try{const e=t.valeur_locative,a=t.region,i=t.residence_principale||!1,p=t.age_proprietaire||0,m=t.handicape||!1,d=s.taxe_fonciere.taux_moyens_par_region[a];let l=e*.5,o=0;const c=[];if(i){const n=l*s.taxe_fonciere.abattements.residence_principale;o+=n,c.push({nom:"Résidence principale",montant:n})}if(p>=s.taxe_fonciere.abattements.personne_agee.seuil_age){const n=l*s.taxe_fonciere.abattements.personne_agee.taux;o+=n,c.push({nom:"Personne âgée (+65 ans)",montant:n})}if(m){const n=l*s.taxe_fonciere.abattements.personne_handicapee;o+=n,c.push({nom:"Personne handicapée",montant:n})}const u=Math.max(0,l-o),v=u*d;return{success:!0,data:{valeurLocative:e,valeurImposable:l,abattements:c,abattementTotal:o,baseImposable:u,tauxRegion:d,taxeFonciere:v,region:a}}}catch{return{success:!1,error:"Erreur lors du calcul. Vérifiez vos données."}}},formatResult:t=>{const e=t.data,a={ile_de_france:"Île-de-France",provence_alpes_cote_azur:"Provence-Alpes-Côte d'Azur",auvergne_rhone_alpes:"Auvergne-Rhône-Alpes",occitanie:"Occitanie",nouvelle_aquitaine:"Nouvelle-Aquitaine",grand_est:"Grand Est",hauts_de_france:"Hauts-de-France",normandie:"Normandie",centre_val_de_loire:"Centre-Val de Loire",bourgogne_franche_comte:"Bourgogne-Franche-Comté",pays_de_la_loire:"Pays de la Loire",bretagne:"Bretagne",corse:"Corse"}[e.region];return`
          <div class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div class="bg-blue-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800">Valeur locative cadastrale</h4>
                <p class="text-xl font-bold text-primary-600">${r(e.valeurLocative)}</p>
              </div>
              <div class="bg-green-50 p-4 rounded-lg">
                <h4 class="font-semibold text-gray-800">Taxe foncière estimée</h4>
                <p class="text-xl font-bold text-green-600">${r(e.taxeFonciere)}</p>
              </div>
            </div>
            
            <div class="border-t pt-4">
              <h4 class="font-semibold text-gray-800 mb-3">Détail du calcul :</h4>
              <div class="space-y-2 text-sm">
                <div class="flex justify-between">
                  <span>Valeur locative cadastrale :</span>
                  <span class="font-medium">${r(e.valeurLocative)}</span>
                </div>
                <div class="flex justify-between">
                  <span>Valeur imposable (abattement 50%) :</span>
                  <span class="font-medium">${r(e.valeurImposable)}</span>
                </div>
                ${e.abattements.length>0?`
                  <div class="text-gray-600 font-medium mt-2">Abattements appliqués :</div>
                  ${e.abattements.map(i=>`
                    <div class="flex justify-between ml-4">
                      <span>• ${i.nom} :</span>
                      <span class="font-medium">-${r(i.montant)}</span>
                    </div>
                  `).join("")}
                `:""}
                <div class="flex justify-between border-t pt-2">
                  <span>Base imposable finale :</span>
                  <span class="font-medium">${r(e.baseImposable)}</span>
                </div>
                <div class="flex justify-between">
                  <span>Taux moyen ${a} :</span>
                  <span class="font-medium">${(e.tauxRegion*100).toFixed(2)}%</span>
                </div>
                <div class="border-t pt-2 flex justify-between font-bold">
                  <span>Taxe foncière 2025 :</span>
                  <span>${r(e.taxeFonciere)}</span>
                </div>
              </div>
            </div>

            <div class="bg-red-50 border border-red-200 rounded-lg p-4 mt-4">
              <p class="text-sm text-red-800">
                <strong>⚠️ Important :</strong> Cette estimation utilise des taux moyens régionaux. 
                <strong>Les taux réels varient énormément selon les communes</strong> (de 10% à plus de 45% !). 
                Consultez votre avis de taxe foncière pour le montant exact.
              </p>
            </div>
            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 mt-4">
              <p class="text-sm text-blue-800">
                <strong>💡 Conseil :</strong> Pour connaître le taux exact de votre commune, 
                consultez le site de votre mairie ou votre dernier avis d'impôt.
              </p>
            </div>
          </div>
        `},exportCSV:{enabled:!1,filename:"taxe-fonciere-estimation.csv",getCSVData:(t,e)=>{const a=t.data;return{headers:["Paramètre","Valeur"],rows:[["Valeur locative cadastrale (€)",a.valeurLocative],["Taux communal (%)",(a.tauxCommunal*100).toFixed(2)],["Taux départemental (%)",(a.tauxDepartemental*100).toFixed(2)],["Taux régional (%)",(a.tauxRegion*100).toFixed(2)],["Taux total (%)",(a.tauxTotal*100).toFixed(2)],["Taxe foncière 2025 (€)",a.taxeFonciere],["Région",a.regionLabel]]}}}};new b("taxe-calculator",x);
