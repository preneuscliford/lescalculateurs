import"./main-C11GuAlR.js";import"./autoExportInit-DC5gTcqy.js";import"./chunk-jspdf-BCzl2gSH.js";document.getElementById("regimeFiscal").addEventListener("change",function(){const n=document.getElementById("taux-personnalise");this.value==="personnalise"?n.classList.remove("hidden"):n.classList.add("hidden")});document.getElementById("dateAchat").addEventListener("change",function(){const n=document.getElementById("dateVente");n.min=this.value});document.getElementById("crypto-bourse-form").addEventListener("submit",function(n){n.preventDefault();const i=document.getElementById("typeActif").value,b=document.getElementById("nomActif").value||i,l=parseFloat(document.getElementById("prixAchat").value)||0,g=parseFloat(document.getElementById("quantiteAchat").value)||0,d=new Date(document.getElementById("dateAchat").value),E=parseFloat(document.getElementById("fraisAchat").value)||0,c=parseFloat(document.getElementById("prixVente").value)||0,s=parseFloat(document.getElementById("quantiteVente").value)||0,p=new Date(document.getElementById("dateVente").value),B=parseFloat(document.getElementById("fraisVente").value)||0,a=document.getElementById("regimeFiscal").value,A=parseFloat(document.getElementById("tauxPersonnalise").value)||30,F=document.getElementById("abattementDuree").checked;if(!l||!g||!c||!s){alert("Veuillez remplir tous les champs obligatoires");return}if(s>g){alert("Vous ne pouvez pas vendre plus que ce que vous avez acheté");return}if(p<=d){alert("La date de vente doit être postérieure à la date d'achat");return}const f=l*s+E*s/g,y=c*s-B,t=y-f,o=Math.floor((p-d)/(1e3*60*60*24*365.25)),w=Math.floor((p-d)/(1e3*60*60*24*30.44));let r=0;F&&i==="actions"&&a==="progressif"&&(o>=8?r=65:o>=2&&(r=50));const x=t*(1-r/100);let u=30;a==="progressif"?u=30:a==="personnalise"&&(u=A);const h=Math.max(0,x*u/100),m=t-h,$=(c-l)/l*100;function e(I){return new Intl.NumberFormat("fr-FR",{style:"currency",currency:"EUR"}).format(I)}function v(I){return I.toLocaleDateString("fr-FR")}const V=`
          <div class="space-y-6">
            <div class="bg-blue-50 border-l-4 border-blue-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-blue-900 mb-4">📊 Résumé de l'opération</h3>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p class="text-sm text-gray-600">Actif</p>
                  <p class="text-lg font-semibold text-gray-900">${b.charAt(0).toUpperCase()+b.slice(1)}</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Quantité</p>
                  <p class="text-lg font-semibold text-gray-900">${s.toLocaleString("fr-FR")}</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Prix d'achat</p>
                  <p class="text-lg font-semibold text-gray-900">${e(l)}</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Prix de vente</p>
                  <p class="text-lg font-semibold text-gray-900">${e(c)}</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Date d'achat</p>
                  <p class="text-lg font-semibold text-gray-900">${v(d)}</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Date de vente</p>
                  <p class="text-lg font-semibold text-gray-900">${v(p)}</p>
                </div>
              </div>
            </div>

            <div class="bg-green-50 border-l-4 border-green-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-green-900 mb-4">💰 Calcul financier</h3>
              <div class="space-y-3">
                <div class="flex justify-between">
                  <span class="text-gray-600">Montant d'achat (frais inclus) :</span>
                  <span class="font-semibold">${e(f)}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Montant de vente (frais déduits) :</span>
                  <span class="font-semibold">${e(y)}</span>
                </div>
                <div class="flex justify-between text-lg">
                  <span class="font-bold text-gray-900">Plus-value brute :</span>
                  <span class="font-bold ${t>=0?"text-green-700":"text-red-700"}">${e(t)}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Rendement :</span>
                  <span class="font-semibold ${$>=0?"text-green-600":"text-red-600"}">${$.toFixed(2)}%</span>
                </div>
              </div>
            </div>

            <div class="bg-purple-50 border-l-4 border-purple-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-purple-900 mb-4">⏰ Durée de détention</h3>
              <div class="space-y-2">
                <p><span class="font-semibold">Durée :</span> ${o} an${o>1?"s":""} et ${w%12} mois</p>
                ${r>0?`
                <p><span class="font-semibold">Abattement :</span> ${r}% (actions détenues > ${o>=8?"8":"2"} ans)</p>
                <p><span class="font-semibold">Plus-value après abattement :</span> ${e(x)}</p>
                `:""}
                ${i==="crypto"?`
                <p class="text-orange-600 text-sm">⚠️ Pas d'abattement pour les cryptomonnaies</p>
                `:""}
              </div>
            </div>

            ${t>0?`
            <div class="bg-red-50 border-l-4 border-red-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-red-900 mb-4">🏛️ Fiscalité</h3>
              <div class="space-y-3">
                <div class="flex justify-between">
                  <span class="text-gray-600">Régime fiscal :</span>
                  <span class="font-semibold">${a==="flat-tax"?"Flat tax 30%":a==="progressif"?"Barème progressif":"Taux personnalisé"}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Base imposable :</span>
                  <span class="font-semibold">${e(x)}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Taux d'imposition :</span>
                  <span class="font-semibold">${u.toFixed(1)}%</span>
                </div>
                <div class="flex justify-between text-lg">
                  <span class="font-bold text-gray-900">Impôt à payer :</span>
                  <span class="font-bold text-red-700">${e(h)}</span>
                </div>
              </div>
            </div>
            `:`
            <div class="bg-gray-50 border-l-4 border-gray-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-gray-900 mb-4">📉 Moins-value</h3>
              <p class="text-gray-600">Cette opération génère une moins-value de ${e(Math.abs(t))}. 
              Elle peut être imputée sur vos plus-values de même nature pour réduire vos impôts.</p>
            </div>
            `}

            <div class="bg-gradient-to-r from-green-50 to-blue-50 border-2 border-green-200 p-6 rounded-lg">
              <h3 class="text-2xl font-bold text-gray-900 mb-4">🎯 Résultat final</h3>
              <div class="flex justify-between items-center text-2xl">
                <span class="font-bold text-gray-900">Gain net après impôts :</span>
                <span class="font-bold ${m>=0?"text-green-600":"text-red-600"}">${e(m)}</span>
              </div>
              ${m>0?`
              <p class="text-sm text-green-700 mt-2">
                💡 Vous conservez ${(m/t*100).toFixed(1)}% de votre plus-value brute après impôts.
              </p>
              `:""}
            </div>

            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <p class="text-sm text-yellow-800">
                <strong>⚠️ Important :</strong> Cette simulation est indicative et basée sur la fiscalité française 2025. 
                Consultez un expert-comptable pour vos déclarations officielles et optimisations fiscales.
              </p>
            </div>

            <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p class="text-sm text-blue-800">
                <strong>📋 À retenir :</strong> 
                ${i==="crypto"?"Les cryptomonnaies sont imposées à 30% sans abattement. Toute cession (vente, échange) est imposable.":"Pour les actions, vous pouvez choisir entre flat tax (30%) et barème progressif avec abattements selon la durée."}
              </p>
            </div>
          </div>
          `;document.getElementById("results").innerHTML=V,document.getElementById("results").classList.remove("hidden"),document.getElementById("export-buttons").classList.remove("hidden"),window.cryptoBourseData={userInputs:{typeActif:i,nomActif:b,prixAchat:l,quantiteAchat:g,dateAchat:v(d),fraisAchat:E,prixVente:c,quantiteVente:s,dateVente:v(p),fraisVente:B,regimeFiscal:a,tauxPersonnalise:a==="personnalise"?A:null,abattementDuree:F},results:{montantAchat:f,montantVente:y,plusValueBrute:t,rendement:$,dureeDetentionAnnees:o,dureeDetentionMois:w,tauxAbattement:r,plusValueApresAbattement:x,tauxImposition:u,impot:h,gainNet:m}},document.getElementById("results").scrollIntoView({behavior:"smooth"})});
