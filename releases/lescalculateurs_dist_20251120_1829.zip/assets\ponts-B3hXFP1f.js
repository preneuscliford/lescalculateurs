import"./main-C11GuAlR.js";import{b as l}from"./baremes-BY9f5jXV.js";import"./autoExportInit-DC5gTcqy.js";import"./chunk-jspdf-BCzl2gSH.js";document.addEventListener("DOMContentLoaded",()=>{const r=document.getElementById("ponts-calendar");function a(){const n=l.jours_feries[2025],u=l.jours_feries[2026],c=`
          <div class="max-w-6xl mx-auto">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
              
              <!-- 2025 -->
              <div class="bg-white rounded-lg shadow-lg p-6">
                <h3 class="text-2xl font-bold text-gray-900 mb-6">Année 2025</h3>
                <div class="space-y-4">
                  ${n.map(t=>{const o=new Date(t.date),e=o.toLocaleDateString("fr-FR",{weekday:"long"}),d=o.toLocaleDateString("fr-FR",{day:"numeric",month:"long"}),s=e==="mardi"||e==="jeudi";return`
                      <div class="flex justify-between items-center p-3 rounded-lg ${s?"bg-yellow-50 border border-yellow-200":"bg-gray-50"}">
                        <div>
                          <div class="font-semibold text-gray-900">${t.nom}</div>
                          <div class="text-sm text-gray-600">${d} (${e})</div>
                        </div>
                        ${s?'<span class="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">Pont possible</span>':""}
                      </div>
                    `}).join("")}
                </div>
              </div>

              <!-- 2026 -->
              <div class="bg-white rounded-lg shadow-lg p-6">
                <h3 class="text-2xl font-bold text-gray-900 mb-6">Année 2026</h3>
                <div class="space-y-4">
                  ${u.map(t=>{const o=new Date(t.date),e=o.toLocaleDateString("fr-FR",{weekday:"long"}),d=o.toLocaleDateString("fr-FR",{day:"numeric",month:"long"}),s=e==="mardi"||e==="jeudi";return`
                      <div class="flex justify-between items-center p-3 rounded-lg ${s?"bg-yellow-50 border border-yellow-200":"bg-gray-50"}">
                        <div>
                          <div class="font-semibold text-gray-900">${t.nom}</div>
                          <div class="text-sm text-gray-600">${d} (${e})</div>
                        </div>
                        ${s?'<span class="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">Pont possible</span>':""}
                      </div>
                    `}).join("")}
                </div>
              </div>
            </div>

            <!-- Conseils pour les ponts -->
            <div class="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h4 class="text-lg font-semibold text-blue-900 mb-3">💡 Conseils pour optimiser vos ponts</h4>
              <div class="space-y-2 text-sm text-blue-800">
                <p>• <strong>Mardi ou jeudi férié :</strong> Posez 1 jour pour un week-end de 4 jours</p>
                <p>• <strong>Lundi ou vendredi férié :</strong> Week-end de 3 jours automatique</p>
                <p>• <strong>Planifiez à l'avance :</strong> Déposez vos demandes de congés dès janvier</p>
                <p>• <strong>Négociez en équipe :</strong> Alternez avec vos collègues pour les ponts populaires</p>
              </div>
            </div>

            <!-- Meilleurs ponts de l'année -->
            <div class="mt-6 bg-green-50 border border-green-200 rounded-lg p-6">
              <h4 class="text-lg font-semibold text-green-900 mb-3">🎯 Meilleurs ponts 2025-2026</h4>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <strong>2025 :</strong>
                  <ul class="mt-1 space-y-1 text-green-800">
                    <li>• 1er mai (jeudi) → Pont du 2 mai</li>
                    <li>• 8 mai (jeudi) → Pont du 9 mai</li>
                    <li>• Ascension (jeudi 29 mai) → Pont du 30 mai</li>
                  </ul>
                </div>
                <div>
                  <strong>2026 :</strong>
                  <ul class="mt-1 space-y-1 text-green-800">
                    <li>• 1er mai (vendredi) → Week-end 3 jours</li>
                    <li>• 8 mai (vendredi) → Week-end 3 jours</li>
                    <li>• Ascension (jeudi 14 mai) → Pont du 15 mai</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        `;r.innerHTML=c}a();const i=()=>{const n=document.getElementById("pdf-export-btn");n&&window.updateButtonState?(console.log("🔄 Mise à jour forcée du bouton Ponts"),window.updateButtonState(n,"Calcul des Ponts")):setTimeout(i,100)};setTimeout(i,200)});
