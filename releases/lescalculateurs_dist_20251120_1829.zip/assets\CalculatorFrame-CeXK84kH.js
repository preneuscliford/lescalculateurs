var p=Object.defineProperty;var x=(u,e,r)=>e in u?p(u,e,{enumerable:!0,configurable:!0,writable:!0,value:r}):u[e]=r;var d=(u,e,r)=>x(u,typeof e!="symbol"?e+"":e,r);import{_ as m}from"./chunk-jspdf-BCzl2gSH.js";class y{constructor(e,r){d(this,"container");d(this,"containerId");d(this,"config");d(this,"values",{});const s=document.getElementById(e);if(!s)throw new Error(`Container with id "${e}" not found`);this.container=s,this.containerId=e,this.config=r,this.render(),this.initFromURL(),this.autoCalculateOnLoad()}render(){this.container.innerHTML=`
      <div class="max-w-4xl mx-auto p-6">
        <div class="bg-white rounded-lg shadow-lg p-6">
          <h2 class="text-2xl font-bold text-gray-800 mb-4">🧮 ${this.config.title}</h2>
          <p class="text-gray-600 mb-6">${this.config.description}</p>
          
          <form id="calculator-form" class="space-y-4">
            ${this.config.fields.map(e=>this.renderField(e)).join("")}
            
            <button type="submit" class="calculator-button w-full">
              ▶️ Calculer
            </button>
          </form>
          
          <div id="calculator-result" class="mt-6 hidden" aria-live="polite"></div>
        </div>
      </div>
    `,this.attachEventListeners()}renderField(e){var t;const r="calculator-input",s=e.required?"required":"";switch(e.type){case"select":return`
          <div>
            <label for="${e.id}" class="block text-sm font-medium text-gray-700 mb-2">
              ${e.label} ${e.required?"*":""}
            </label>
            <select id="${e.id}" name="${e.id}" class="${r}" ${s}>
              <option value="">Sélectionnez...</option>
              ${((t=e.options)==null?void 0:t.map(a=>`<option value="${a.value}">${a.label}</option>`).join(""))||""}
            </select>
          </div>
        `;case"checkbox":return`
          <div class="flex items-center">
            <input type="checkbox" id="${e.id}" name="${e.id}" 
                   class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded">
            <label for="${e.id}" class="ml-2 block text-sm text-gray-700">
              ${e.label}
            </label>
          </div>
        `;case"number":return`
          <div>
            <label for="${e.id}" class="block text-sm font-medium text-gray-700 mb-2">
              ${e.label} ${e.required?"*":""}
            </label>
            <input type="number" id="${e.id}" name="${e.id}" 
                   class="${r}" 
                   placeholder="${e.placeholder||""}"
                   min="${e.min||""}"
                   max="${e.max||""}"
                   step="${e.step||"any"}"
                   ${s}>
          </div>
        `;default:return`
          <div>
            <label for="${e.id}" class="block text-sm font-medium text-gray-700 mb-2">
              ${e.label} ${e.required?"*":""}
            </label>
            <input type="text" id="${e.id}" name="${e.id}" 
                   class="${r}" 
                   placeholder="${e.placeholder||""}"
                   ${s}>
          </div>
        `}}attachEventListeners(){const e=this.container.querySelector("#calculator-form"),r=this.container.querySelector("#calculator-result");e.addEventListener("submit",s=>{s.preventDefault(),this.handleSubmit(e,r)}),this.config.fields.forEach(s=>{const t=this.container.querySelector(`#${s.id}`);t&&t.addEventListener("change",()=>{this.updateValue(s.id,t)})})}autoCalculateOnLoad(){try{const e=this.container.querySelector("#calculator-form"),r=this.container.querySelector("#calculator-result");if(!e||!r)return;if(this.config.fields.filter(t=>t.required).every(t=>{const a=this.values[t.id];return a!=null&&String(a)!==""})){const t=this.config.calculate(this.values);this.showResult(r,t);return}try{const t=`calculator_history_${this.containerId}`,a=JSON.parse(localStorage.getItem(t)||"[]");if(Array.isArray(a)&&a.length>0){const o=a[0].values||{};Object.keys(o).forEach(l=>{const n=e.querySelector(`#${CSS.escape(l)}`);n&&(n.type==="checkbox"?n.checked=!!o[l]:n.value=String(o[l]),this.updateValue(l,n))});const c=this.config.calculate(this.values);this.showResult(r,c)}}catch{}}catch{}}updateValue(e,r){r.type==="checkbox"?this.values[e]=r.checked:r.type==="number"?this.values[e]=parseFloat(r.value)||0:this.values[e]=r.value}handleSubmit(e,r){this.config.fields.forEach(t=>{const a=e.querySelector(`#${t.id}`);a&&this.updateValue(t.id,a)});const s=this.config.fields.filter(t=>t.required&&!this.values[t.id]).map(t=>t.label);if(s.length>0){this.showResult(r,{success:!1,error:`Veuillez remplir les champs obligatoires : ${s.join(", ")}`});return}try{const t=this.config.calculate(this.values);this.showResult(r,t),t.success&&this.containerId==="notaire-calculator"&&(window.dernierCalculNotaire={result:t,values:{...this.values}},console.log("✅ Calcul notaire stocké",window.dernierCalculNotaire)),this.saveHistory(this.values,t),this.updateURL(this.values),(window.dataLayer||[]).push({event:"calculator_submit",calculator:this.config.title})}catch{this.showResult(r,{success:!1,error:"Erreur lors du calcul. Vérifiez vos données."})}}showResult(e,r){if(e.classList.remove("hidden"),r.success){const s=this.config.exportCSV&&this.config.exportCSV.enabled===!0,t=this.config.exportXLSX&&this.config.exportXLSX.enabled===!0,a="";e.className="mt-6 calculator-result",e.innerHTML=`
        <h3 class="text-lg font-semibold text-gray-800 mb-2">Résultat :</h3>
        <div class="text-gray-700">
          ${this.config.formatResult(r)}
        </div>
        ${a}
      `;const i=document.getElementById("export-buttons");if(i&&(s||t)){if(s&&!document.getElementById("export-csv-btn")){const o=document.createElement("button");o.id="export-csv-btn",o.className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50",o.textContent="📄 Exporter en CSV",o.addEventListener("click",c=>{c.preventDefault(),this.handleCSVExport(r)}),i.appendChild(o)}if(t&&!document.getElementById("export-xlsx-btn")){const o=document.createElement("button");o.id="export-xlsx-btn",o.className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50",o.textContent="📊 Exporter en XLSX",o.addEventListener("click",c=>{c.preventDefault(),this.handleXLSXExport(r)}),i.appendChild(o)}}if(!i&&(s||t)){const o=new MutationObserver(c=>{const l=document.getElementById("export-buttons");if(l){if(s&&!document.getElementById("export-csv-btn")){const n=document.createElement("button");n.id="export-csv-btn",n.className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50",n.textContent="📄 Exporter en CSV",n.addEventListener("click",h=>{h.preventDefault(),this.handleCSVExport(r)}),l.appendChild(n)}if(t&&!document.getElementById("export-xlsx-btn")){const n=document.createElement("button");n.id="export-xlsx-btn",n.className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50",n.textContent="📊 Exporter en XLSX",n.addEventListener("click",h=>{h.preventDefault(),this.handleXLSXExport(r)}),l.appendChild(n)}o.disconnect()}});o.observe(document.body,{childList:!0,subtree:!0})}}else e.className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg",e.innerHTML=`
        <div class="text-red-700">
          <strong>Erreur :</strong> ${r.error}
        </div>
      `}async handleCSVExport(e){var r,s;try{const{exportToCSV:t}=await m(async()=>{const{exportToCSV:o}=await import("./csvExport-CFwnbfd3.js");return{exportToCSV:o}},[]);let a;(r=this.config.exportCSV)!=null&&r.getCSVData?a=this.config.exportCSV.getCSVData(e,this.values):a={headers:["Champ","Valeur"],rows:[...Object.entries(this.values).map(([o,c])=>[o,c]),["Résultat",JSON.stringify(e.data)]]};const i=((s=this.config.exportCSV)==null?void 0:s.filename)||`${this.config.title.toLowerCase().replace(/\s+/g,"_")}_resultats.csv`;t(a,i)}catch(t){console.error("Erreur lors de l'export CSV:",t),alert("Erreur lors de l'export CSV. Veuillez réessayer.")}}async handleXLSXExport(e){var r,s,t;try{const{exportToXLSX:a}=await m(async()=>{const{exportToXLSX:c}=await import("./csvExport-CFwnbfd3.js");return{exportToXLSX:c}},[]);let i;(r=this.config.exportXLSX)!=null&&r.getXLSXData?i=this.config.exportXLSX.getXLSXData(e,this.values):(s=this.config.exportCSV)!=null&&s.getCSVData?i=this.config.exportCSV.getCSVData(e,this.values):i={headers:["Champ","Valeur"],rows:[...Object.entries(this.values).map(([c,l])=>[c,l]),["Résultat",JSON.stringify(e.data)]]};const o=((t=this.config.exportXLSX)==null?void 0:t.filename)||`${this.config.title.toLowerCase().replace(/\s+/g,"_")}_resultats.xlsx`;await a(i,o)}catch(a){console.error("Erreur lors de l'export XLSX:",a),alert("Erreur lors de l'export XLSX. Veuillez réessayer.")}}getValues(){return{...this.values}}setValues(e){Object.assign(this.values,e),Object.entries(e).forEach(([r,s])=>{const t=this.container.querySelector(`#${r}`);t&&(t.type==="checkbox"?t.checked=!!s:t.value=String(s))})}initFromURL(){try{const e=new URLSearchParams(window.location.search);if(e.size===0)return;const r=this.container.querySelector("#calculator-form");if(!r)return;e.forEach((s,t)=>{const a=r.querySelector(`#${CSS.escape(t)}`);a&&(a.type==="checkbox"?a.checked=s==="true":a.value=s,this.updateValue(t,a))})}catch{}}updateURL(e){try{const r=new URLSearchParams;Object.entries(e).forEach(([t,a])=>{a==null||a===""||r.set(t,String(a))});const s=`${window.location.pathname}?${r.toString()}`;window.history.replaceState({},document.title,s)}catch{}}saveHistory(e,r){try{const s=`calculator_history_${this.containerId}`,t=JSON.parse(localStorage.getItem(s)||"[]"),i=[{ts:Date.now(),values:{...e},result:r},...t].slice(0,10);localStorage.setItem(s,JSON.stringify(i))}catch{}}}export{y as C};
