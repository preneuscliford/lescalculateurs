import"./main-C11GuAlR.js";import"./autoExportInit-DC5gTcqy.js";import"./chunk-jspdf-BCzl2gSH.js";document.getElementById("charges-form").addEventListener("submit",function(k){k.preventDefault();const s=parseFloat(document.getElementById("surface").value)||0,o=document.getElementById("nombreLots").value,t=document.getElementById("ageBatiment").value,d=document.getElementById("localisation").value,$=document.getElementById("etatGeneral").value,p=document.getElementById("ascenseur").checked,m=document.getElementById("gardien").checked,b=document.getElementById("parking").checked,x=document.getElementById("jardin").checked,g=document.getElementById("piscine").checked,y=document.getElementById("chauffage").checked;if(!s||s<10){alert("Veuillez saisir une surface valide (minimum 10 m²)");return}let l=0;switch(d){case"paris":l=50;break;case"grande-ville":l=35;break;case"ville-moyenne":l=28;break;case"petite-ville":l=22;break}let r=1;switch(o){case"petit":r=1.4;break;case"moyen":r=1;break;case"grand":r=.85;break;case"tres-grand":r=.75;break}let n=1;switch(t){case"neuf":n=.7;break;case"recent":n=.85;break;case"moyen":n=1;break;case"ancien":n=1.2;break;case"tres-ancien":n=1.4;break}let i=1;switch($){case"excellent":i=.9;break;case"bon":i=1;break;case"moyen":i=1.15;break;case"mauvais":i=1.35;break}let e=l*r*n*i;p&&(e+=8),m&&(e+=15),b&&(e+=3),x&&(e+=2),g&&(e+=12),y&&(e+=18);let a=0;switch(t){case"neuf":a=5;break;case"recent":a=8;break;case"moyen":a=15;break;case"ancien":a=25;break;case"tres-ancien":a=35;break}p&&(t==="ancien"||t==="tres-ancien")&&(a+=10);const u=e+a,f=u*s,E=f/12,v=35,c=(u-v)/v*100;function h(C){return new Intl.NumberFormat("fr-FR",{style:"currency",currency:"EUR"}).format(C)}const w=e*.25,B=e*.35,I=e*.15,j=e*.25,F=`
          <div class="space-y-6">
            <div class="bg-blue-50 border-l-4 border-blue-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-blue-900 mb-4">🏢 Caractéristiques de votre copropriété</h3>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p class="text-sm text-gray-600">Surface de votre lot</p>
                  <p class="text-lg font-semibold text-gray-900">${s} m²</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Taille de la copropriété</p>
                  <p class="text-lg font-semibold text-gray-900">${o==="petit"?"Petite (&lt; 10 lots)":o==="moyen"?"Moyenne (10-50 lots)":o==="grand"?"Grande (50-200 lots)":"Très grande (&gt; 200 lots)"}</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Âge du bâtiment</p>
                  <p class="text-lg font-semibold text-gray-900">${t==="neuf"?"Neuf (&lt; 5 ans)":t==="recent"?"Récent (5-15 ans)":t==="moyen"?"Standard (15-40 ans)":t==="ancien"?"Ancien (40-70 ans)":"Très ancien (&gt; 70 ans)"}</p>
                </div>
                <div>
                  <p class="text-sm text-gray-600">Localisation</p>
                  <p class="text-lg font-semibold text-gray-900">${d==="paris"?"Paris":d==="grande-ville"?"Grande ville":d==="ville-moyenne"?"Ville moyenne":"Petite ville"}</p>
                </div>
              </div>
            </div>

            <div class="bg-green-50 border-l-4 border-green-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-green-900 mb-4">💰 Estimation des charges</h3>
              <div class="space-y-3">
                <div class="flex justify-between">
                  <span class="text-gray-600">Charges courantes :</span>
                  <span class="font-semibold">${e.toFixed(1)} €/m²/an</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Charges exceptionnelles :</span>
                  <span class="font-semibold">${a.toFixed(1)} €/m²/an</span>
                </div>
                <div class="border-t pt-2 flex justify-between text-lg">
                  <span class="font-bold text-gray-900">Total :</span>
                  <span class="font-bold text-green-700">${u.toFixed(1)} €/m²/an</span>
                </div>
              </div>
            </div>

            <div class="bg-purple-50 border-l-4 border-purple-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-purple-900 mb-4">📊 Budget mensuel et annuel</h3>
              <div class="space-y-3">
                <div class="flex justify-between text-lg">
                  <span class="font-bold text-gray-900">Montant mensuel :</span>
                  <span class="font-bold text-purple-700">${h(E)}</span>
                </div>
                <div class="flex justify-between text-xl">
                  <span class="font-bold text-gray-900">Montant annuel :</span>
                  <span class="font-bold text-purple-700">${h(f)}</span>
                </div>
                <div class="mt-4 p-3 ${c>0?"bg-red-100 border border-red-300":"bg-green-100 border border-green-300"} rounded">
                  <p class="text-sm ${c>0?"text-red-700":"text-green-700"}">
                    ${c>0?"⬆️":"⬇️"} ${Math.abs(c).toFixed(1)}% ${c>0?"au-dessus":"en-dessous"} de la moyenne nationale (35 €/m²/an)
                  </p>
                </div>
              </div>
            </div>

            <div class="bg-gray-50 border-l-4 border-gray-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-gray-900 mb-4">📋 Répartition des charges courantes</h3>
              <div class="space-y-3">
                <div class="flex justify-between">
                  <span class="text-gray-600">Entretien et maintenance (35%) :</span>
                  <span class="font-semibold">${(B*s/12).toFixed(0)} €/mois</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Services et équipements (25%) :</span>
                  <span class="font-semibold">${(j*s/12).toFixed(0)} €/mois</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Syndic et administration (25%) :</span>
                  <span class="font-semibold">${(w*s/12).toFixed(0)} €/mois</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-gray-600">Assurances et divers (15%) :</span>
                  <span class="font-semibold">${(I*s/12).toFixed(0)} €/mois</span>
                </div>
              </div>
            </div>

            ${p||m||g?`
            <div class="bg-yellow-50 border-l-4 border-yellow-500 p-6 rounded-r-lg">
              <h3 class="text-xl font-bold text-yellow-900 mb-4">⚡ Équipements identifiés</h3>
              <div class="space-y-2">
                ${p?'<p class="text-sm text-gray-700">🔹 Ascenseur : +8 €/m²/an (maintenance, électricité, modernisation)</p>':""}
                ${m?'<p class="text-sm text-gray-700">🔹 Gardien/Concierge : +15 €/m²/an (salaire, charges sociales, logement)</p>':""}
                ${y?'<p class="text-sm text-gray-700">🔹 Chauffage collectif : +18 €/m²/an (combustible, maintenance chaudière)</p>':""}
                ${g?'<p class="text-sm text-gray-700">🔹 Piscine : +12 €/m²/an (produits, électricité, surveillance)</p>':""}
                ${b?'<p class="text-sm text-gray-700">🔹 Parking collectif : +3 €/m²/an (éclairage, entretien)</p>':""}
                ${x?'<p class="text-sm text-gray-700">🔹 Espaces verts : +2 €/m²/an (jardinage, arrosage)</p>':""}
              </div>
            </div>
            `:""}

            <div class="text-sm text-gray-500 bg-gray-50 p-4 rounded">
              <p><strong>💡 Conseils pour optimiser vos charges :</strong></p>
              <ul class="list-disc list-inside mt-2 space-y-1">
                <li>Comparez les contrats de syndic tous les 3 ans</li>
                <li>Négociez les contrats d'entretien (ascenseur, chauffage, nettoyage)</li>
                <li>Investissez dans l'isolation pour réduire les charges de chauffage</li>
                <li>Participez aux assemblées générales pour contrôler les dépenses</li>
                <li>Demandez plusieurs devis pour les gros travaux</li>
              </ul>
            </div>
          </div>
        `;document.getElementById("results").innerHTML=F,document.getElementById("results").classList.remove("hidden"),document.getElementById("results").scrollIntoView({behavior:"smooth"})});
